// CarCatalog.kt

package com.sandip.nikamusic.car

import android.content.Context
import androidx.media3.common.MediaItem
import com.music.innertube.YouTube
import com.music.innertube.models.AlbumItem
import com.music.innertube.models.PlaylistItem
import com.music.innertube.models.SongItem
import com.music.innertube.models.WatchEndpoint
import com.music.innertube.models.YTItem
import com.sandip.nikamusic.constants.HideVideoSongsKey
import com.sandip.nikamusic.constants.SongSortType
import com.sandip.nikamusic.db.MusicDatabase
import com.sandip.nikamusic.db.entities.Album
import com.sandip.nikamusic.db.entities.Artist
import com.sandip.nikamusic.db.entities.Playlist
import com.sandip.nikamusic.db.entities.Song
import com.sandip.nikamusic.extensions.filterVideoSongs
import com.sandip.nikamusic.extensions.toMediaItem
import com.sandip.nikamusic.models.MediaMetadata
import com.sandip.nikamusic.models.toMediaMetadata
import com.sandip.nikamusic.playback.queues.ListQueue
import com.sandip.nikamusic.playback.queues.Queue
import com.sandip.nikamusic.playback.queues.YouTubeQueue
import com.sandip.nikamusic.utils.dataStore
import com.sandip.nikamusic.utils.get
import com.sandip.nikamusic.viewmodels.HomeFeedCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

// a song as the car shows it and plays it
class CarSong(
    val id: String,
    val title: String,
    val subtitle: String,
    val thumbnail: String?,
    val item: MediaItem,
    val metadata: MediaMetadata,
    // youtube's own way into the song's radio, when it came from youtube
    val endpoint: WatchEndpoint? = null,
)

// a list the car can open: a playlist, an album, an artist's songs
class CarCollection(
    val key: String,
    val title: String,
    val subtitle: String?,
    val thumbnail: String?,
    val round: Boolean = false,
    val songs: suspend () -> List<CarSong>,
)

// one home category, the same rows the phone's home shows: its songs to play and the lists to open
class CarShelf(
    val title: String,
    val thumbnail: String?,
    val songs: List<CarSong>,
    val collections: List<CarCollection>,
)

// where every car screen gets its songs and lists, all read off the main thread
class CarCatalog(
    private val context: Context,
    private val database: MusicDatabase,
) {
    private val hideVideoSongs: Boolean get() = context.dataStore.get(HideVideoSongsKey, false)

    // the phone home's quick picks: the most played of the last month, or what played last when nothing has yet
    suspend fun quickPicks(): List<CarSong> = io {
        val monthAgo = System.currentTimeMillis() - MonthMs
        val top = database.mostPlayedSongs(fromTimeStamp = monthAgo, limit = QuickPicks).first().filterVideoSongs(hideVideoSongs)
        val picks = top.ifEmpty { database.recentlyPlayedSongs(limit = QuickPicks).first().filterVideoSongs(hideVideoSongs) }
        picks.distinctBy { it.id }.map { it.toCarSong() }
    }

    // home's categories as the phone last worked them out, then youtube's own home, so the car never waits on the recommender
    suspend fun shelves(): List<CarShelf> = io {
        val cache = HomeFeedCache(context)
        val categories = cache.loadCategories().orEmpty().map { Triple(it.title, it.thumbnailUrl, it.items) }
        val sections = categories.ifEmpty {
            val home = cache.loadHomePage() ?: YouTube.home().getOrNull()
            home?.sections.orEmpty().map { Triple(it.title, it.thumbnail, it.items) }
        }
        sections.mapNotNull { (title, thumbnail, items) -> shelf(title, thumbnail, items) }
    }

    suspend fun recentSongs(): List<CarSong> = io {
        database.recentlyPlayedSongs(limit = RecentSongs).first().filterVideoSongs(hideVideoSongs).map { it.toCarSong() }
    }

    suspend fun recentCollections(): List<CarCollection> = io {
        val albums = database.recentlyPlayedAlbums(limit = RecentLists).first().map { it.toCollection() }
        val playlists = database.recentlyPlayedPlaylists(limit = RecentLists).first().map { it.toCollection() }
        albums + playlists
    }

    suspend fun likedCount(): Int = io { database.likedSongsCount().first() }

    suspend fun downloadedCount(): Int = io { database.downloadedSongs(SongSortType.CREATE_DATE, true).first().size }

    suspend fun liked(): List<CarSong> = io { database.likedSongs(SongSortType.CREATE_DATE, true).first().map { it.toCarSong() } }

    suspend fun downloaded(): List<CarSong> = io { database.downloadedSongs(SongSortType.CREATE_DATE, true).first().map { it.toCarSong() } }

    suspend fun playlists(): List<CarCollection> = io { database.playlistsByCreateDateAsc().first().asReversed().map { it.toCollection() } }

    suspend fun albums(): List<CarCollection> = io { database.albumsByCreateDateAsc().first().asReversed().map { it.toCollection() } }

    suspend fun artists(): List<CarCollection> = io { database.artistsByCreateDateAsc().first().asReversed().map { it.toCollection() } }

    // a song picked on its own starts its radio, the same as on the phone's home
    fun radio(song: CarSong): Queue = YouTubeQueue(song.endpoint ?: WatchEndpoint(videoId = song.id), song.metadata)

    // a song picked from a list plays that list from there
    fun listFrom(title: String, songs: List<CarSong>, index: Int): Queue =
        ListQueue(title = title, items = songs.map { it.item }, startIndex = index.coerceIn(0, (songs.size - 1).coerceAtLeast(0)))

    private fun shelf(title: String, thumbnail: String?, items: List<YTItem>): CarShelf? {
        val songs = items.filterIsInstance<SongItem>().map { it.toCarSong() }
        val collections = items.mapNotNull { item ->
            when (item) {
                is AlbumItem -> item.toCollection()
                is PlaylistItem -> item.toCollection()
                else -> null
            }
        }
        if (songs.isEmpty() && collections.isEmpty()) return null
        return CarShelf(title, thumbnail ?: items.firstNotNullOfOrNull { it.thumbnail }, songs, collections)
    }

    private fun Song.toCarSong() = CarSong(
        id = id,
        title = song.title,
        subtitle = artists.joinToString { it.name },
        thumbnail = song.thumbnailUrl,
        item = toMediaItem(),
        metadata = toMediaMetadata(),
    )

    private fun SongItem.toCarSong() = CarSong(
        id = id,
        title = title,
        subtitle = artists.joinToString { it.name },
        thumbnail = thumbnail,
        item = toMediaItem(),
        metadata = toMediaMetadata(),
        endpoint = endpoint,
    )

    private fun Playlist.toCollection() = CarCollection(
        key = "playlist/$id",
        title = playlist.name,
        subtitle = context.resources.getQuantityString(com.sandip.nikamusic.R.plurals.n_song, songCount, songCount),
        thumbnail = playlist.thumbnailUrl ?: songThumbnails.firstOrNull { !it.isNullOrBlank() },
    ) { io { database.playlistSongs(id).first().map { it.song.toCarSong() } } }

    private fun Album.toCollection() = CarCollection(
        key = "album/$id",
        title = album.title,
        subtitle = artists.joinToString { it.name },
        thumbnail = album.thumbnailUrl,
    ) { io { database.albumSongs(id).first().map { it.toCarSong() } } }

    private fun Artist.toCollection() = CarCollection(
        key = "artist/$id",
        title = artist.name,
        subtitle = context.resources.getQuantityString(com.sandip.nikamusic.R.plurals.n_song, songCount, songCount),
        thumbnail = artist.thumbnailUrl,
        round = true,
    ) { io { database.artistSongsByCreateDateAsc(id).first().asReversed().map { it.toCarSong() } } }

    private fun AlbumItem.toCollection() = CarCollection(
        key = "yt-album/$browseId",
        title = title,
        subtitle = artists?.joinToString { it.name },
        thumbnail = thumbnail,
    ) { io { YouTube.album(browseId).getOrNull()?.songs.orEmpty().map { it.toCarSong() } } }

    private fun PlaylistItem.toCollection() = CarCollection(
        key = "yt-playlist/$id",
        title = title,
        subtitle = author?.name,
        thumbnail = thumbnail,
    ) { io { YouTube.playlist(id).getOrNull()?.songs.orEmpty().map { it.toCarSong() } } }

    private suspend fun <T> io(block: suspend () -> T): T = withContext(Dispatchers.IO) { block() }

    private companion object {
        const val MonthMs = 30L * 24 * 60 * 60 * 1000
        const val QuickPicks = 20
        const val RecentSongs = 30
        const val RecentLists = 6
    }
}

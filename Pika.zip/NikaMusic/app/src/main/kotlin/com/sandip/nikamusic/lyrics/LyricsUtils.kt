// LyricsUtils.kt

package com.sandip.nikamusic.lyrics

import android.text.format.DateUtils
import com.atilika.kuromoji.ipadic.Tokenizer
import com.github.promeg.pinyinhelper.Pinyin
import com.sandip.nikamusic.db.entities.LyricsEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import java.util.Locale

@Suppress("RegExpRedundantEscape")
object LyricsUtils {
    val LINE_REGEX = "((\\[\\d\\d:\\d\\d\\.\\d{2,3}\\] ?)+)(.+)".toRegex()
    val TIME_REGEX = "\\[(\\d\\d):(\\d\\d)\\.(\\d{2,3})\\]".toRegex()

    private val RICH_SYNC_LINE_REGEX = "\\[(\\d{1,2}):(\\d{2})\\.(\\d{2,3})\\](.+)".toRegex()
    private val RICH_SYNC_WORD_REGEX = "<(\\d{1,2}):(\\d{2})\\.(\\d{2,3})>\\s*([^<]+)".toRegex()
    private val RICH_SYNC_TAG_REGEX = "<\\d{1,2}:\\d{2}\\.\\d{2,3}>".toRegex()

    private val AGENT_REGEX = "\\{agent:([^}]+)\\}".toRegex()
    private val BACKGROUND_REGEX = "^\\{bg\\}".toRegex()

    private val KANA_ROMAJI_MAP: Map<String, String> = mapOf(

        "キャ" to "kya", "キュ" to "kyu", "キョ" to "kyo",
        "シャ" to "sha", "シュ" to "shu", "ショ" to "sho",
        "チャ" to "cha", "チュ" to "chu", "チョ" to "cho",
        "ニャ" to "nya", "ニュ" to "nyu", "ニョ" to "nyo",
        "ヒャ" to "hya", "ヒュ" to "hyu", "ヒョ" to "hyo",
        "ミャ" to "mya", "ミュ" to "myu", "ミョ" to "myo",
        "リャ" to "rya", "リュ" to "ryu", "リョ" to "ryo",
        "ギャ" to "gya", "ギュ" to "gyu", "ギョ" to "gyo",
        "ジャ" to "ja", "ジュ" to "ju", "ジョ" to "jo",
        "ヂャ" to "ja", "ヂュ" to "ju", "ヂョ" to "jo",
        "ビャ" to "bya", "ビュ" to "byu", "ビョ" to "byo",
        "ピャ" to "pya", "ピュ" to "pyu", "ピョ" to "pyo",

        // loanword sounds built with small kana, which used to leak into the reading as katakana
        "ティ" to "ti", "ディ" to "di", "トゥ" to "tu", "ドゥ" to "du", "テュ" to "tyu", "デュ" to "dyu",
        "ファ" to "fa", "フィ" to "fi", "フェ" to "fe", "フォ" to "fo", "フュ" to "fyu",
        "ウィ" to "wi", "ウェ" to "we", "ウォ" to "wo", "イェ" to "ye",
        "ヴァ" to "va", "ヴィ" to "vi", "ヴェ" to "ve", "ヴォ" to "vo", "ヴュ" to "vyu",
        "シェ" to "she", "ジェ" to "je", "チェ" to "che",
        "ツァ" to "tsa", "ツィ" to "tsi", "ツェ" to "tse", "ツォ" to "tso",
        "クァ" to "kwa", "グァ" to "gwa",

        "ア" to "a", "イ" to "i", "ウ" to "u", "エ" to "e", "オ" to "o",
        "カ" to "ka", "キ" to "ki", "ク" to "ku", "ケ" to "ke", "コ" to "ko",
        "サ" to "sa", "シ" to "shi", "ス" to "su", "セ" to "se", "ソ" to "so",
        "タ" to "ta", "チ" to "chi", "ツ" to "tsu", "テ" to "te", "ト" to "to",
        "ナ" to "na", "ニ" to "ni", "ヌ" to "nu", "ネ" to "ne", "ノ" to "no",
        "ハ" to "ha", "ヒ" to "hi", "フ" to "fu", "ヘ" to "he", "ホ" to "ho",
        "マ" to "ma", "ミ" to "mi", "ム" to "mu", "メ" to "me", "モ" to "mo",
        "ヤ" to "ya", "ユ" to "yu", "ヨ" to "yo",
        "ラ" to "ra", "リ" to "ri", "ル" to "ru", "レ" to "re", "ロ" to "ro",
        "ワ" to "wa", "ヲ" to "o", "ン" to "n",

        "ガ" to "ga", "ギ" to "gi", "グ" to "gu", "ゲ" to "ge", "ゴ" to "go",
        "ザ" to "za", "ジ" to "ji", "ズ" to "zu", "ゼ" to "ze", "ゾ" to "zo",
        "ダ" to "da", "ヂ" to "ji", "ヅ" to "zu", "デ" to "de", "ド" to "do",

        "バ" to "ba", "ビ" to "bi", "ブ" to "bu", "ベ" to "be", "ボ" to "bo",
        "パ" to "pa", "ピ" to "pi", "プ" to "pu", "ペ" to "pe", "ポ" to "po",
        "ヴ" to "vu",

        "ァ" to "a", "ィ" to "i", "ゥ" to "u", "ェ" to "e", "ォ" to "o",
        "ャ" to "ya", "ュ" to "yu", "ョ" to "yo", "ヮ" to "wa",
        "ヰ" to "i", "ヱ" to "e", "ヵ" to "ka", "ヶ" to "ke",
    )

    private val HANGUL_ROMAJA_MAP: Map<String, Map<String, String>> = mapOf(
        "cho" to mapOf(
            "ᄀ" to "g", "ᄁ" to "kk", "ᄂ" to "n", "ᄃ" to "d",
            "ᄄ" to "tt", "ᄅ" to "r", "ᄆ" to "m", "ᄇ" to "b",
            "ᄈ" to "pp", "ᄉ" to "s", "ᄊ" to "ss", "ᄋ" to "",
            "ᄌ" to "j", "ᄍ" to "jj", "ᄎ" to "ch", "ᄏ" to "k",
            "ᄐ" to "t", "ᄑ" to "p", "ᄒ" to "h"
        ),
        "jung" to mapOf(
            "ᅡ" to "a", "ᅢ" to "ae", "ᅣ" to "ya", "ᅤ" to "yae",
            "ᅥ" to "eo", "ᅦ" to "e", "ᅧ" to "yeo", "ᅨ" to "ye",
            "ᅩ" to "o", "ᅪ" to "wa", "ᅫ" to "wae", "ᅬ" to "oe",
            "ᅭ" to "yo", "ᅮ" to "u", "ᅯ" to "wo", "ᅰ" to "we",
            "ᅱ" to "wi", "ᅲ" to "yu", "ᅳ" to "eu", "ᅴ" to "eui",
            "ᅵ" to "i"
        ),
        "jong" to mapOf(
            "ᆨ" to "k", "ᆨᄋ" to "g", "ᆨᄂ" to "ngn", "ᆨᄅ" to "ngn", "ᆨᄆ" to "ngm", "ᆨᄒ" to "kh",
            "ᆩ" to "kk", "ᆩᄋ" to "kg", "ᆩᄂ" to "ngn", "ᆩᄅ" to "ngn", "ᆩᄆ" to "ngm", "ᆩᄒ" to "kh",
            "ᆪ" to "k", "ᆪᄋ" to "ks", "ᆪᄂ" to "ngn", "ᆪᄅ" to "ngn", "ᆪᄆ" to "ngm", "ᆪᄒ" to "kch",
            "ᆫ" to "n", "ᆫᄅ" to "ll", "ᆬ" to "n", "ᆬᄋ" to "nj", "ᆬᄂ" to "nn", "ᆬᄅ" to "nn",
            "ᆬᄆ" to "nm", "ᆬㅎ" to "nch", "ᆭ" to "n", "ᆭᄋ" to "nh", "ᆭᄅ" to "nn", "ᆮ" to "t",
            "ᆮᄋ" to "d", "ᆮᄂ" to "nn", "ᆮᄅ" to "nn", "ᆮᄆ" to "nm", "ᆮᄒ" to "th", "ᆯ" to "l",
            "ᆯᄋ" to "r", "ᆯᄂ" to "ll", "ᆯᄅ" to "ll", "ᆰ" to "k", "ᆰᄋ" to "lg", "ᆰᄂ" to "ngn",
            "ᆰᄅ" to "ngn", "ᆰᄆ" to "ngm", "ᆰᄒ" to "lkh", "ᆱ" to "m", "ᆱᄋ" to "lm", "ᆱᄂ" to "mn",
            "ᆱᄅ" to "mn", "ᆱᄆ" to "mm", "ᆱᄒ" to "lmh", "ᆲ" to "p", "ᆲᄋ" to "lb", "ᆲᄂ" to "mn",
            "ᆲᄅ" to "mn", "ᆲᄆ" to "mm", "ᆲᄒ" to "lph", "ᆳ" to "t", "ᆳᄋ" to "ls", "ᆳᄂ" to "nn",
            "ᆳᄅ" to "nn", "ᆳᄆ" to "nm", "ᆳᄒ" to "lsh", "ᆴ" to "t", "ᆴᄋ" to "lt", "ᆴᄂ" to "nn",
            "ᆴᄅ" to "nn", "ᆴᄆ" to "nm", "ᆴᄒ" to "lth", "ᆵ" to "p", "ᆵᄋ" to "lp", "ᆵᄂ" to "mn",
            "ᆵᄅ" to "mn", "ᆵᄆ" to "mm", "ᆵᄒ" to "lph", "ᆶ" to "l", "ᆶᄋ" to "lh", "ᆶᄂ" to "ll",
            "ᆶᄅ" to "ll", "ᆶᄆ" to "lm", "ᆶᄒ" to "lh", "ᆷ" to "m", "ᆷᄅ" to "mn", "ᆸ" to "p",
            "ᆸᄋ" to "b", "ᆸᄂ" to "mn", "ᆸᄅ" to "mn", "ᆸᄆ" to "mm", "ᆸᄒ" to "ph", "ᆹ" to "p",
            "ᆹᄋ" to "ps", "ᆹᄂ" to "mn", "ᆹᄅ" to "mn", "ᆹᄆ" to "mm", "ᆹᄒ" to "psh", "ᆺ" to "t",
            "ᆺᄋ" to "s", "ᆺᄂ" to "nn", "ᆺᄅ" to "nn", "ᆺᄆ" to "nm", "ᆺᄒ" to "sh", "ᆻ" to "t",
            "ᆻᄋ" to "ss", "ᆻᄂ" to "tn", "ᆻᄅ" to "tn", "ᆻᄆ" to "nm", "ᆻᄒ" to "th", "ᆼ" to "ng",
            "ᆽ" to "t", "ᆽᄋ" to "j", "ᆽᄂ" to "nn", "ᆽᄅ" to "nn", "ᆽᄆ" to "nm", "ᆽᄒ" to "ch",
            "ᆾ" to "t", "ᆾᄋ" to "ch", "ᆾᄂ" to "nn", "ᆾᄅ" to "nn", "ᆾᄆ" to "nm", "ᆾᄒ" to "ch",
            "ᆿ" to "k", "ᆿᄋ" to "k", "ᆿᄂ" to "ngn", "ᆿᄅ" to "ngn", "ᆿᄆ" to "ngm", "ᆿᄒ" to "kh",
            "ᇀ" to "t", "ᇀᄋ" to "t", "ᇀᄂ" to "nn", "ᇀᄅ" to "nn", "ᇀᄆ" to "nm", "ᇀᄒ" to "th",
            "ᇁ" to "p", "ᇁᄋ" to "p", "ᇁᄂ" to "mn", "ᇁᄅ" to "mn", "ᇁᄆ" to "mm", "ᇁᄒ" to "ph",
            "ᇂ" to "t", "ᇂᄋ" to "h", "ᇂᄂ" to "nn", "ᇂᄅ" to "nn", "ᇂᄆ" to "mm", "ᇂᄒ" to "t",
            "ᇂᄀ" to "k"
        )
    )

    private val DEVANAGARI_ROMAJI_MAP: Map<String, String> = mapOf(
        "अ" to "a", "आ" to "aa", "इ" to "i", "ई" to "ee", "उ" to "u", "ऊ" to "oo",
        "ऋ" to "ri", "ए" to "e", "ऐ" to "ai", "ओ" to "o", "औ" to "au",
        "क" to "k", "ख" to "kh", "ग" to "g", "घ" to "gh", "ङ" to "ng",
        "च" to "ch", "छ" to "chh", "ज" to "j", "झ" to "jh", "ञ" to "ny",
        "ट" to "t", "ठ" to "th", "ड" to "d", "ढ" to "dh", "ण" to "n",
        "त" to "t", "थ" to "th", "द" to "d", "ध" to "dh", "न" to "n",
        "प" to "p", "फ" to "ph", "ब" to "b", "भ" to "bh", "म" to "m",
        "य" to "y", "र" to "r", "ल" to "l", "व" to "v",
        "श" to "sh", "ष" to "sh", "स" to "s", "ह" to "h",
        "क्ष" to "ksh", "त्र" to "tr", "ज्ञ" to "gy", "श्र" to "shr",
        "ा" to "aa", "ि" to "i", "ी" to "ee", "ु" to "u", "ू" to "oo",
        "ृ" to "ri", "े" to "e", "ै" to "ai", "ो" to "o", "ौ" to "au",
        "ं" to "n", "ः" to "h", "ँ" to "n", "़" to "", "्" to "",
        "०" to "0", "१" to "1", "२" to "2", "३" to "3", "४" to "4",
        "५" to "5", "६" to "6", "७" to "7", "८" to "8", "९" to "9",
        "ॐ" to "Om", "ऽ" to "",
        "क़" to "q", "ख़" to "kh", "ग़" to "g", "ज़" to "z", "ड़" to "r", "ढ़" to "rh", "फ़" to "f", "य़" to "y",

        "क\u093C" to "q", "ख\u093C" to "kh", "ग\u093C" to "g", "ज\u093C" to "z", "ड\u093C" to "r", "ढ\u093C" to "rh", "फ\u093C" to "f", "य\u093C" to "y"
    )

    private val GURMUKHI_ROMAJI_MAP: Map<String, String> = mapOf(
        "ੳ" to "o", "ਅ" to "a", "ੲ" to "e", "ਸ" to "s", "ਹ" to "h",
        "ਕ" to "k", "ਖ" to "kh", "ਗ" to "g", "ਘ" to "gh", "ਙ" to "ng",
        "ਚ" to "ch", "ਛ" to "chh", "ਜ" to "j", "ਝ" to "jh", "ਞ" to "ny",
        "ਟ" to "t", "ਠ" to "th", "ਡ" to "d", "ਢ" to "dh", "ਣ" to "n",
        "ਤ" to "t", "ਥ" to "th", "ਦ" to "d", "ਧ" to "dh", "ਨ" to "n",
        "ਪ" to "p", "ਫ" to "ph", "ਬ" to "b", "ਭ" to "bh", "ਮ" to "m",
        "ਯ" to "y", "ਰ" to "r", "ਲ" to "l", "ਵ" to "v", "ੜ" to "r",
        "ਸ਼" to "sh", "ਖ਼" to "kh", "ਗ਼" to "g", "ਜ਼" to "z", "ਫ਼" to "f", "ਲ਼" to "l",
        "ਾ" to "aa", "ਿ" to "i", "ੀ" to "ee", "ੁ" to "u", "ੂ" to "oo",
        "ੇ" to "e", "ੈ" to "ai", "ੋ" to "o", "ੌ" to "au",
        "ੰ" to "n", "ਂ" to "n", "ੱ" to "", "੍" to "", "਼" to "",
        "ੴ" to "Ek Onkar",
        "੦" to "0", "੧" to "1", "੨" to "2", "੩" to "3", "੪" to "4",
        "੫" to "5", "੬" to "6", "੭" to "7", "੮" to "8", "੯" to "9"
    )

    private val GENERAL_CYRILLIC_ROMAJI_MAP: Map<String, String> = mapOf(
        "А" to "A", "Б" to "B", "В" to "V", "Г" to "G", "Ґ" to "G", "Д" to "D",
        "Ѓ" to "Ǵ", "Ђ" to "Đ", "Е" to "E", "Ё" to "Yo", "Є" to "Ye", "Ж" to "Zh",
        "З" to "Z", "Ѕ" to "Dz", "И" to "I", "І" to "I", "Ї" to "Yi", "Й" to "Y",
        "Ј" to "Y", "К" to "K", "Л" to "L", "Љ" to "Ly", "М" to "M", "Н" to "N",
        "Њ" to "Ny", "О" to "O", "П" to "P", "Р" to "R", "С" to "S", "Т" to "T",
        "Ћ" to "Ć", "У" to "U", "Ў" to "Ŭ", "Ф" to "F", "Х" to "Kh", "Ц" to "Ts",
        "Ч" to "Ch", "Џ" to "Dž", "Ш" to "Sh", "Щ" to "Shch", "Ъ" to "ʺ", "Ы" to "Y",
        "Ь" to "ʹ", "Э" to "E", "Ю" to "Yu", "Я" to "Ya",
        "Ѡ" to "O", "Ѣ" to "Ya", "Ѥ" to "Ye", "Ѧ" to "Ya", "Ѩ" to "Ya",
        "Ѫ" to "U", "Ѭ" to "Yu", "Ѯ" to "Ks", "Ѱ" to "Ps", "Ѳ" to "F",
        "Ѵ" to "I", "Ѷ" to "I", "Ғ" to "Gh", "Ҕ" to "G", "Җ" to "Zh",
        "Ҙ" to "Dz", "Қ" to "Q", "Ҝ" to "K", "Ҟ" to "K", "Ҡ" to "K",
        "Ң" to "Ng", "Ҥ" to "Ng", "Ҧ" to "P", "Ҩ" to "O", "Ҫ" to "S",
        "Ҭ" to "T", "Ү" to "U", "Ұ" to "U", "Ҳ" to "Kh", "Ҵ" to "Ts",
        "Ҷ" to "Ch", "Ҹ" to "Ch", "Һ" to "H", "Ҽ" to "Ch", "Ҿ" to "Ch",
        "Ќ" to "Ḱ", "Ө" to "Ö",

        "а" to "a", "б" to "b", "в" to "v", "г" to "g", "ґ" to "g", "д" to "d",
        "ѓ" to "ǵ", "ђ" to "đ", "е" to "e", "ё" to "yo", "є" to "ye", "ж" to "zh",
        "з" to "z", "ѕ" to "dz", "и" to "i", "і" to "i", "ї" to "yi", "й" to "y",
        "ј" to "y", "к" to "k", "л" to "l", "љ" to "ly", "м" to "m", "н" to "n",
        "њ" to "ny", "о" to "o", "п" to "p", "р" to "r", "с" to "s", "т" to "t",
        "ћ" to "ć", "у" to "u", "ў" to "ŭ", "ф" to "f", "х" to "kh", "ц" to "ts",
        "ч" to "ch", "џ" to "dž", "ш" to "sh", "щ" to "shch", "ъ" to "ʺ", "ы" to "y",
        "ь" to "ʹ", "э" to "e", "ю" to "yu", "я" to "ya",
        "ѡ" to "o", "ѣ" to "ya", "ѥ" to "ye", "ѧ" to "ya", "ѩ" to "ya",
        "ѫ" to "u", "ѭ" to "yu", "ѯ" to "ks", "ѱ" to "ps", "ѳ" to "f",
        "ѵ" to "i", "ѷ" to "i", "ғ" to "gh", "ҕ" to "g", "җ" to "zh",
        "ҙ" to "dz", "қ" to "q", "ҝ" to "k", "ҟ" to "k", "ҡ" to "k",
        "ң" to "ng", "ҥ" to "ng", "ҧ" to "p", "ҩ" to "o", "ҫ" to "s",
        "ҭ" to "t", "ү" to "u", "ұ" to "u", "ҳ" to "kh", "ҵ" to "ts",
        "ҷ" to "ch", "ҹ" to "ch", "һ" to "h", "ҽ" to "ch", "ҿ" to "ch",
        "ќ" to "ḱ", "ө" to "ö"
    )

    private val RUSSIAN_ROMAJI_MAP: Map<String, String> = mapOf(
        "ого" to "ovo", "Ого" to "Ovo", "его" to "evo", "Его" to "Evo"
    )

    private val UKRAINIAN_ROMAJI_MAP: Map<String, String> = mapOf(
        "Г" to "H", "г" to "h",
        "Ґ" to "G", "ґ" to "g",
        "Є" to "Ye", "є" to "ye",
        "І" to "I", "і" to "i",
        "Ї" to "Yi", "ї" to "yi"
    )

    private val SERBIAN_ROMAJI_MAP: Map<String, String> = mapOf(
        "Ж" to "Ž", "Љ" to "Lj", "Њ" to "Nj", "Ц" to "C", "Ч" to "Č",
        "Џ" to "Dž", "Ш" to "Š", "Х" to "H",

        "ж" to "ž", "љ" to "lj", "њ" to "nj", "ц" to "c", "ч" to "č",
        "џ" to "dž", "ш" to "š", "х" to "h"
    )

    private val BULGARIAN_ROMAJI_MAP: Map<String, String> = mapOf(
        "Ж" to "Zh", "Ц" to "Ts", "Ч" to "Ch", "Ш" to "Sh", "Щ" to "Sht",
        "Ъ" to "A", "Ь" to "Y", "Ю" to "Yu", "Я" to "Ya",

        "ж" to "zh", "ц" to "ts", "ч" to "ch", "ш" to "sh", "щ" to "sht",
        "ъ" to "a", "ь" to "y", "ю" to "yu", "я" to "ya"
    )

    private val BELARUSIAN_ROMAJI_MAP: Map<String, String> = mapOf(
        "Г" to "H", "г" to "h", "Ў" to "W", "ў" to "w"
    )

    private val KYRGYZ_ROMAJI_MAP: Map<String, String> = mapOf(
        "Ү" to "Ü", "ү" to "ü", "Ы" to "Y", "ы" to "y"
    )

    private val MACEDONIAN_ROMAJI_MAP: Map<String, String> = mapOf(
        "Ѓ" to "Gj", "Ѕ" to "Dz", "И" to "I", "Ј" to "J", "Љ" to "Lj",
        "Њ" to "Nj", "Ќ" to "Kj", "Џ" to "Dž", "Ч" to "Č", "Ш" to "Sh",
        "Ж" to "Zh", "Ц" to "C", "Х" to "H",

        "ѓ" to "gj", "ѕ" to "dz", "и" to "i", "ј" to "j", "љ" to "lj",
        "њ" to "nj", "ќ" to "kj", "џ" to "dž", "ч" to "č", "ш" to "sh",
        "ж" to "zh", "ц" to "c", "х" to "h"
    )

    private val RUSSIAN_CYRILLIC_LETTERS = setOf(
        "А", "Б", "В", "Г", "Д", "Е", "Ё", "Ж", "З", "И", "Й", "К", "Л", "М", "Н",
        "О", "П", "Р", "С", "Т", "У", "Ф", "Х", "Ц", "Ч", "Ш", "Щ", "Ъ", "Ы", "Ь",
        "Э", "Ю", "Я",

        "а", "б", "в", "г", "д", "е", "ё", "ж", "з", "и", "й", "к", "л", "м", "н",
        "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "ъ", "ы", "ь",
        "э", "ю", "я"
    )

    private val UKRAINIAN_CYRILLIC_LETTERS = setOf(
       "А", "Б", "В", "Г", "Ґ", "Д", "Е", "Є", "Ж", "З", "И", "І", "Ї", "Й",
        "К", "Л", "М", "Н", "О", "П", "Р", "С", "Т", "У", "Ф", "Х", "Ц", "Ч",
        "Ш", "Щ", "Ь", "Ю", "Я",

        "а", "б", "в", "г", "ґ", "д", "е", "є", "ж", "з", "и", "і", "ї", "й",
        "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч",
        "ш", "щ", "ь", "ю", "я"
    )

    private val SERBIAN_CYRILLIC_LETTERS = setOf(
        "А", "Б", "В", "Г", "Д", "Ђ", "Е", "Ж", "З", "И", "Ј", "К", "Л", "Љ", "М",
        "Н", "Њ", "О", "П", "Р", "С", "Т", "Ћ", "У", "Ф", "Х", "Ц", "Ч", "Џ", "Ш",

        "а", "б", "в", "г", "д", "ђ", "е", "ж", "з", "и", "ј", "к", "л", "љ", "м",
        "н", "њ", "о", "п", "р", "с", "т", "ћ", "у", "ф", "х", "ц", "ч", "џ", "ш"
    )

    private val BULGARIAN_CYRILLIC_LETTERS = setOf(
        "А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М",
        "Н", "О", "П", "Р", "С", "Т", "У", "Ф", "Х", "Ц", "Ч", "Ш", "Щ",
        "Ъ", "Ь", "Ю", "Я",

        "а", "б", "в", "г", "д", "е", "ж", "з", "и", "й", "к", "л", "м",
        "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ",
        "ъ", "ь", "ю", "я"
    )

    private val BELARUSIAN_CYRILLIC_LETTERS = setOf(
        "А", "Б", "В", "Г", "Д", "Е", "Ё", "Ж", "З", "І", "Й", "К", "Л", "М", "Н",
        "О", "П", "Р", "С", "Т", "У", "Ў", "Ф", "Х", "Ц", "Ч", "Ш", "Ь", "Ю", "Я",
        "Ы", "Э",

        "а", "б", "в", "г", "д", "е", "ё", "ж", "з", "і", "й", "к", "л", "м", "н",
        "о", "п", "р", "с", "т", "у", "ў", "ф", "х", "ц", "ч", "ш", "ь", "ю", "я",
        "ы", "э"
    )

    private val KYRGYZ_CYRILLIC_LETTERS = setOf(
        "А", "Б", "В", "Г", "Д", "Е", "Ё", "Ж", "З", "И", "Й", "К", "Л", "М", "Н",
        "Ң", "О", "Ө", "П", "Р", "С", "Т", "У", "Ү", "Ф", "Х", "Ц", "Ч", "Ш", "Щ",
        "Ъ", "Ы", "Ь", "Э", "Ю", "Я",

        "а", "б", "в", "г", "д", "е", "ё", "ж", "з", "и", "й", "к", "л", "м", "н",
        "ң", "о", "ө", "п", "р", "с", "т", "у", "ү", "ф", "х", "ц", "ч", "ш", "щ",
        "ъ", "ы", "ь", "э", "ю", "я"
    )

    private val MACEDONIAN_CYRILLIC_LETTERS = setOf(
        "А", "Б", "В", "Г", "Д", "Ѓ", "Е", "Ж", "З", "Ѕ", "И", "Ј", "К", "Л",
        "Љ", "М", "Н", "Њ", "О", "П", "Р", "С", "Т", "Ќ", "У", "Ф", "Х",
        "Ц", "Ч", "Џ", "Ш",

        "а", "б", "в", "г", "д", "ѓ", "е", "ж", "з", "ѕ", "и", "ј", "к", "л",
        "љ", "м", "н", "њ", "о", "п", "р", "с", "т", "ќ", "у", "ф", "х",
        "ц", "ч", "џ", "ш"
    )

    private val UKRAINIAN_SPECIFIC_CYRILLIC_LETTERS = setOf(
        "Ґ", "ґ", "Є", "є", "І", "і", "Ї", "ї"
    )

    private val SERBIAN_SPECIFIC_CYRILLIC_LETTERS = setOf(
        "Ђ", "ђ", "Ј", "ј", "Љ", "љ", "Њ", "њ", "Ћ", "ћ", "Џ", "џ"
    )

    private val BELARUSIAN_SPECIFIC_CYRILLIC_LETTERS = setOf(
        "Ў", "ў", "І", "і"
    )

    private val KYRGYZ_SPECIFIC_CYRILLIC_LETTERS = setOf(
        "Ң", "ң", "Ө", "ө", "Ү", "ү"
    )

    private val MACEDONIAN_SPECIFIC_CYRILLIC_LETTERS = setOf(
        "Ѓ", "ѓ", "Ѕ", "ѕ", "Ќ", "ќ"
    )

    private val kuromojiTokenizer: Tokenizer by lazy {
        Tokenizer()
    }

    private val HEX_ENTITY_REGEX = "&#x([0-9a-fA-F]+);".toRegex()
    private val DEC_ENTITY_REGEX = "&#(\\d+);".toRegex()

    private fun decodeHtmlEntities(text: String): String =
        text
            .replace(HEX_ENTITY_REGEX) { match ->
                match.groupValues[1].toIntOrNull(16)
                    ?.takeIf { it in 0..0x10FFFF }
                    ?.let { String(Character.toChars(it)) }
                    ?: match.value
            }
            .replace(DEC_ENTITY_REGEX) { match ->
                match.groupValues[1].toIntOrNull()
                    ?.takeIf { it in 0..0x10FFFF }
                    ?.let { String(Character.toChars(it)) }
                    ?: match.value
            }
            .replace("&apos;", "'")
            .replace("&quot;", "\"")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")

    fun isSyllableSplit(rawLyrics: String): Boolean {
        if (rawLyrics.isBlank()) return false
        val entries = try {
            parseLyrics(rawLyrics)
        } catch (_: Exception) {
            return false
        }
        if (entries.size < 4) return false

        var checked = 0
        var flagged = 0
        for (entry in entries) {
            val text = entry.text.trim()
            val letters = text.filter(Char::isLetter)
            if (letters.isEmpty()) continue

            val latin = letters.count { it.code < 0x250 }
            if (latin.toDouble() / letters.length < 0.9) continue

            val tokens = text.split(Regex("\\s+")).filter { it.any(Char::isLetter) }
            if (tokens.size < 4) continue
            checked++

            val lengths = tokens.map { it.count(Char::isLetter) }
            val shortRatio = lengths.count { it <= 3 }.toDouble() / lengths.size
            val mean = lengths.sum().toDouble() / lengths.size
            if (shortRatio >= 0.8 && mean < 2.8) flagged++
        }

        return checked >= 4 && flagged.toDouble() / checked >= 0.65
    }

    fun parseLyrics(lyrics: String): List<LyricsEntry> {

        val unescapedLyrics = lyrics
            .trim()
            .removePrefix("\"")
            .removeSuffix("\"")
            .replace("\\\\", "\\")
            .replace("\\n", "\n")
            .replace("\\r", "\r")
            .replace("\\t", "\t")

        val decodedLyrics = decodeHtmlEntities(unescapedLyrics)

        val lines = decodedLyrics.lines()
            .filter { it.isNotBlank() && !it.trim().startsWith("[offset:") }

        val isRichSync = lines.any { line ->
            RICH_SYNC_LINE_REGEX.matches(line.trim()) &&
            RICH_SYNC_WORD_REGEX.containsMatchIn(line)
        }

        val parsed = if (isRichSync) {
            parseRichSyncLyrics(lines)
        } else {
            parseStandardLyrics(lines)
        }
        return fixWordSpacing(parsed)
    }

    // the last few songs' parsed lines, never handed out themselves, since each caller fills its own reading flows
    private val parsedCache = object : LinkedHashMap<String, List<LyricsEntry>>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, List<LyricsEntry>>?) = size > 4
    }

    // same as parseLyrics, but the card, the page and the styles stop re-parsing one song on the main thread
    fun parseLyricsCached(lyrics: String): List<LyricsEntry> {
        val template = synchronized(parsedCache) { parsedCache[lyrics] }
            ?: parseLyrics(lyrics).also { parsed -> synchronized(parsedCache) { parsedCache[lyrics] = parsed } }
        return template.map { entry ->
            entry.copy(
                romanizedTextFlow = MutableStateFlow(null),
                rubyFlow = MutableStateFlow(null),
                translatedTextFlow = MutableStateFlow(null),
                romanizedWordsFlow = MutableStateFlow(null),
            )
        }
    }

    // parse in the background as soon as a song's lyrics land, so opening the player finds them ready
    fun warmParsedLyrics(lyrics: String?) {
        if (lyrics.isNullOrBlank() || lyrics == LyricsEntity.LYRICS_NOT_FOUND) return
        if (synchronized(parsedCache) { parsedCache.containsKey(lyrics) }) return
        val parsed = runCatching { parseLyrics(lyrics) }.getOrNull() ?: return
        synchronized(parsedCache) { parsedCache[lyrics] = parsed }
    }

    /**
     * Repairs the two ways a line's word timings and its text come apart, so every lyrics style
     * shows the same words:
     *
     *  - **Syllables timed as words** ("a" "gain", "lo" "ve"). The line text is right, but the
     *    styles that lay out one timed word after another with a space between showed "let down a
     *    gain you will not.. I thin k I lo ve yo u". Pieces with no space between them in the
     *    line are one word, and are merged into it. The pieces themselves stay in
     *    [LyricsEntry.syllables] for the main style, which sweeps syllable by syllable.
     *  - **No spaces at all** ("<t>I<t>love<t>you" reads "Iloveyou"). When nearly every
     *    multi-word line of a song has no space in it, the source dropped them: its timed pieces
     *    are the words, and the text is rebuilt with spaces between them.
     *
     * Neither touches Chinese, Japanese or Thai, which are written without spaces.
     */
    private fun fixWordSpacing(entries: List<LyricsEntry>): List<LyricsEntry> {
        if (entries.none { (it.words?.size ?: 0) > 1 }) return entries
        val spacesDropped = spacesDropped(entries)
        return entries.map { entry ->
            val words = entry.words?.takeIf { it.size > 1 } ?: return@map entry
            val text = if (spacesDropped && isGluedLine(entry.text, words)) spacedText(words) else entry.text
            val merged = mergeWordPieces(text, words)
            if (text == entry.text && merged == words) {
                entry
            } else {
                entry.copy(text = text, words = merged, syllables = words.takeIf { it.size != merged.size })
            }
        }
    }

    /** Scripts written without spaces between words: their timed pieces are never merged. */
    private val UnspacedScripts = setOf(Script.HAN, Script.KANA, Script.THAI)

    /** Two or more timed pieces on a line in a spaced script with no space anywhere in it. */
    private fun isGluedLine(text: String, words: List<WordTimestamp>): Boolean =
        words.count { it.text.isNotBlank() } >= 2 &&
            text.none(Char::isWhitespace) &&
            dominantScript(text).let { it !in UnspacedScripts && it != Script.UNKNOWN }

    /**
     * Whether the source left out the spaces between words: at least three multi-piece lines in a
     * spaced script, four in five of them with no space at all, and those split into three or more
     * pieces on average. Lyrics timed in syllables still have spaces between their words on most
     * lines, so they never get this far, and neither do a few glued "oh-oh"s.
     */
    private fun spacesDropped(entries: List<LyricsEntry>): Boolean {
        val lines = entries.filter { entry ->
            val words = entry.words ?: return@filter false
            words.count { it.text.isNotBlank() } >= 2 &&
                dominantScript(entry.text).let { it !in UnspacedScripts && it != Script.UNKNOWN }
        }
        if (lines.size < 3) return false
        val glued = lines.filter { it.text.none(Char::isWhitespace) }
        if (glued.size * 5 < lines.size * 4) return false
        val pieces = glued.sumOf { line -> line.words!!.count { it.text.isNotBlank() } }
        return pieces >= glued.size * 3
    }

    private const val NoSpaceBefore = ",.!?;:)]}…"
    private const val NoSpaceAfter = "([{"
    private val ContractionPiece = Regex("^['’](s|t|re|ll|m|ve|d)$", RegexOption.IGNORE_CASE)

    /** Timed words as a line of text: a space between each, but not before punctuation. */
    private fun spacedText(words: List<WordTimestamp>): String = buildString {
        words.map { it.text.trim() }.filter { it.isNotEmpty() }.forEach { piece ->
            val attached = piece.first() in NoSpaceBefore || ContractionPiece.matches(piece)
            if (isNotEmpty() && !attached && last() !in NoSpaceAfter) append(' ')
            append(piece)
        }
    }

    /**
     * [words] as whole words of [text]: consecutive pieces with nothing between them in the text
     * become one word, timed from the first piece's start to the last one's end. Blank pieces (a
     * timed space) drop out. A piece that can't be found in the text is left as it is.
     */
    private fun mergeWordPieces(text: String, words: List<WordTimestamp>): List<WordTimestamp> {
        val pieces = words.filter { it.text.isNotBlank() }
        val ranges = wordCharRanges(text, pieces)
        val merged = ArrayList<WordTimestamp>(pieces.size)
        var lastEnd = -1
        pieces.forEachIndexed { index, piece ->
            val range = ranges[index]
            val previous = merged.lastOrNull()
            val glued = !range.isEmpty() && range.first == lastEnd &&
                scriptOf(text[lastEnd - 1]) !in UnspacedScripts &&
                scriptOf(text[range.first]) !in UnspacedScripts
            if (previous != null && glued) {
                merged[merged.lastIndex] = WordTimestamp(
                    text = previous.text + piece.text.trim(),
                    startTime = previous.startTime,
                    endTime = maxOf(previous.endTime, piece.endTime),
                )
            } else {
                merged += WordTimestamp(piece.text.trim(), piece.startTime, piece.endTime)
            }
            lastEnd = if (range.isEmpty()) -1 else range.last + 1
        }
        return merged
    }

    private fun parseRichSyncLyrics(lines: List<String>): List<LyricsEntry> {
        val result = mutableListOf<LyricsEntry>()

        lines.forEachIndexed { index, line ->
            val matchResult = RICH_SYNC_LINE_REGEX.matchEntire(line.trim())
            if (matchResult != null) {
                val minutes = matchResult.groupValues[1].toLongOrNull() ?: 0L
                val seconds = matchResult.groupValues[2].toLongOrNull() ?: 0L
                val centiseconds = matchResult.groupValues[3].toLongOrNull() ?: 0L

                val millisPart = if (matchResult.groupValues[3].length == 3) centiseconds else centiseconds * 10
                val lineTimeMs = minutes * DateUtils.MINUTE_IN_MILLIS + seconds * DateUtils.SECOND_IN_MILLIS + millisPart

                var content = matchResult.groupValues[4].trimStart()

                val agentMatch = AGENT_REGEX.find(content)
                val agent = agentMatch?.groupValues?.get(1)
                if (agentMatch != null) {
                    content = content.replaceFirst(AGENT_REGEX, "")
                }

                val isBackground = BACKGROUND_REGEX.containsMatchIn(content)
                if (isBackground) {
                    content = content.replaceFirst(BACKGROUND_REGEX, "")
                }

                val wordTimings = parseRichSyncWords(content, index, lines)

                // Strip the word tags and nothing else. The old pattern also ate the whitespace
                // after each tag, and some sources carry the gap between words as its own timed
                // piece ("<t>I<t> <t>love<t> <t>you") or put it after the tag ("<t> love"), so the
                // spaces went with the tags and the line read "Iloveyou".
                val plainText = repairRichSyncPlainText(
                    content.replace(RICH_SYNC_TAG_REGEX, "").trim()
                )

                if (plainText.isNotBlank()) {
                    result.add(LyricsEntry(lineTimeMs, plainText, wordTimings, agent = agent, isBackground = isBackground))
                }
            }
        }

        return result.sorted()
    }

    /**
     * Undoes the old syllable-split cache format ("wa nt  yo u": syllables single-spaced, words
     * double-spaced) and otherwise only normalises whitespace.
     *
     * The rejoin used to fire on ANY double space in a line, and it glues together every run of
     * short words, so one stray double space turned "I love you  baby" into "Iloveyou baby". It
     * now needs the line to actually look syllable-split: most double-spaced groups have to be
     * made of several pieces. Real text with an odd double space has mostly single-word groups.
     */
    internal fun repairRichSyncPlainText(text: String): String {
        val compacted = text.replace(Regex("[\\t\\u00A0]+"), " ").trim()
        if (compacted.isBlank()) return compacted
        if (!Regex(" {2,}").containsMatchIn(compacted)) {
            return compacted.replace(Regex(" +"), " ")
        }

        val groups = compacted.split(Regex(" {2,}")).filter { it.isNotBlank() }
        val multiPiece = groups.count { it.trim().contains(' ') }
        if (multiPiece * 2 <= groups.size) {
            return compacted.replace(Regex(" +"), " ")
        }

        return groups
            .joinToString(" ") { wordGroup ->
                val parts = wordGroup.trim().split(Regex(" +")).filter { it.isNotBlank() }
                if (parts.size > 1 && parts.all { part -> part.length <= 4 && part.any(Char::isLetter) }) {
                    parts.joinToString("")
                } else {
                    wordGroup.trim().replace(Regex(" +"), " ")
                }
            }
    }

    private fun parseRichSyncWords(content: String, currentIndex: Int, allLines: List<String>): List<WordTimestamp>? {
        val wordMatches = RICH_SYNC_WORD_REGEX.findAll(content).toList()

        if (wordMatches.isEmpty()) return null

        val wordTimings = mutableListOf<WordTimestamp>()

        wordMatches.forEachIndexed { index, match ->
            val minutes = match.groupValues[1].toLongOrNull() ?: 0L
            val seconds = match.groupValues[2].toLongOrNull() ?: 0L
            val fraction = match.groupValues[3].toLongOrNull() ?: 0L

            val fractionPart = if (match.groupValues[3].length == 3) fraction / 1000.0 else fraction / 100.0
            val startTimeSeconds = minutes * 60.0 + seconds + fractionPart

            val wordText = match.groupValues[4].trim()

            val endTimeSeconds = if (index < wordMatches.size - 1) {
                val nextMatch = wordMatches[index + 1]
                val nextMinutes = nextMatch.groupValues[1].toLongOrNull() ?: 0L
                val nextSeconds = nextMatch.groupValues[2].toLongOrNull() ?: 0L
                val nextFraction = nextMatch.groupValues[3].toLongOrNull() ?: 0L
                val nextFractionPart = if (nextMatch.groupValues[3].length == 3) nextFraction / 1000.0 else nextFraction / 100.0
                nextMinutes * 60.0 + nextSeconds + nextFractionPart
            } else {

                val nextLineTime = getNextLineStartTime(currentIndex, allLines)
                nextLineTime ?: (startTimeSeconds + 0.5)
            }

            if (wordText.isNotBlank()) {
                wordTimings.add(WordTimestamp(wordText, startTimeSeconds, endTimeSeconds))
            }
        }

        return if (wordTimings.isNotEmpty()) wordTimings else null
    }

    private fun getNextLineStartTime(currentIndex: Int, allLines: List<String>): Double? {
        if (currentIndex + 1 >= allLines.size) return null

        val nextLine = allLines[currentIndex + 1].trim()
        val matchResult = RICH_SYNC_LINE_REGEX.matchEntire(nextLine) ?: return null

        val minutes = matchResult.groupValues[1].toLongOrNull() ?: return null
        val seconds = matchResult.groupValues[2].toLongOrNull() ?: return null
        val fraction = matchResult.groupValues[3].toLongOrNull() ?: 0L

        val fractionPart = if (matchResult.groupValues[3].length == 3) fraction / 1000.0 else fraction / 100.0
        return minutes * 60.0 + seconds + fractionPart
    }

    private fun parseStandardLyrics(lines: List<String>): List<LyricsEntry> {
        val result = mutableListOf<LyricsEntry>()

        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            if (!line.trim().startsWith("<") || !line.trim().endsWith(">")) {
                val entries = parseLine(line, null)
                if (entries != null) {
                    val wordTimestamps = if (i + 1 < lines.size) {
                        val nextLine = lines[i + 1]
                        if (nextLine.trim().startsWith("<") && nextLine.trim().endsWith(">")) {
                            parseWordTimestamps(nextLine.trim().removeSurrounding("<", ">"))
                        } else null
                    } else null

                    if (wordTimestamps != null) {
                        result.addAll(entries.map { entry ->
                            LyricsEntry(entry.time, entry.text, wordTimestamps, agent = entry.agent, isBackground = entry.isBackground)
                        })
                    } else {
                        result.addAll(entries)
                    }
                }
            }
            i++
        }
        return result.sorted()
    }

    private fun parseWordTimestamps(data: String): List<WordTimestamp>? {
        if (data.isBlank()) return null
        return try {
            data.split("|").mapNotNull { wordData ->
                val parts = wordData.split(":")
                if (parts.size == 3) {
                    WordTimestamp(
                        text = parts[0],
                        startTime = parts[1].toDouble(),
                        endTime = parts[2].toDouble()
                    )
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parseLine(line: String, words: List<WordTimestamp>? = null): List<LyricsEntry>? {
        if (line.isEmpty()) {
            return null
        }
        val matchResult = LINE_REGEX.matchEntire(line.trim()) ?: return null
        val times = matchResult.groupValues[1]
        var text = matchResult.groupValues[3]
        val timeMatchResults = TIME_REGEX.findAll(times)

        val agentMatch = AGENT_REGEX.find(text)
        val agent = agentMatch?.groupValues?.get(1)
        if (agentMatch != null) {
            text = text.replaceFirst(AGENT_REGEX, "")
        }

        val isBackground = BACKGROUND_REGEX.containsMatchIn(text)
        if (isBackground) {
            text = text.replaceFirst(BACKGROUND_REGEX, "")
        }

        return timeMatchResults
            .map { timeMatchResult ->
                val min = timeMatchResult.groupValues[1].toLong()
                val sec = timeMatchResult.groupValues[2].toLong()
                val milString = timeMatchResult.groupValues[3]
                var mil = milString.toLong()
                if (milString.length == 2) {
                    mil *= 10
                }
                val time = min * DateUtils.MINUTE_IN_MILLIS + sec * DateUtils.SECOND_IN_MILLIS + mil
                LyricsEntry(time, text, words, agent = agent, isBackground = isBackground)
            }.toList()
    }

    /**
     * How early a line lights up before its own timestamp. Singers anticipate the beat and the
     * scroll needs a head start, but this is also why a line can look "wrong" at the boundary, so
     * it is a named constant rather than a literal buried in the loop.
     */
    const val LineLeadInMs = 300L

    /**
     * Index of the line that should read as ACTIVE at [position], or -1 before the first line.
     *
     * Returns [lines].size — one past the end — once playback has run past the final line's own
     * end, so callers can tell "the last line is being sung" apart from "the lyrics are over".
     * Without that distinction the last line stayed lit through the entire outro.
     */
    fun findCurrentLineIndex(
        lines: List<LyricsEntry>,
        position: Long,
    ): Int {
        if (lines.isEmpty()) return -1
        if (position >= lyricsEndMs(lines)) return lines.size
        for (index in lines.indices) {
            if (lines[index].time >= position + LineLeadInMs) {
                return index - 1
            }
        }
        return lines.lastIndex
    }

    /**
     * When a line stops being sung: the end of its last word if the line is word-synced, otherwise
     * the start of the next line, otherwise a plain-LRC guess.
     */
    fun lineEndMs(lines: List<LyricsEntry>, index: Int): Long {
        val entry = lines.getOrNull(index) ?: return 0L
        entry.words?.lastOrNull()?.let { return (it.endTime * 1000).toLong() }
        lines.getOrNull(index + 1)?.let { return it.time }
        return entry.time + UntimedLineDurationMs
    }

    /** Where the lyrics as a whole finish. */
    fun lyricsEndMs(lines: List<LyricsEntry>): Long {
        if (lines.isEmpty()) return 0L
        return lineEndMs(lines, lines.lastIndex)
    }

    /** Fallback duration for a line with no word timings and no successor. */
    private const val UntimedLineDurationMs = 5_000L

    // ---------------------------------------------------------------------------------------
    // Provider result grading
    //
    // These exist because provider selection used to accept a result on
    // `contains("<") && contains(">") && contains(":")`, which is true of any LRC file with an
    // emoticon in it and false of several genuinely word-synced formats. Grading a result means
    // parsing it once and looking at what actually came out.
    // ---------------------------------------------------------------------------------------

    /**
     * Whether parsed [lines] carry no usable timing: several lines, no word timings, and every
     * line on the same timestamp. Some providers hand back unsynced lyrics as LRC with each line
     * stamped [00:00.00]; played as synced, the whole song counted as "already sung" a few seconds
     * in and every line sat blurred and dimmed.
     */
    fun isUnsynced(lines: List<LyricsEntry>): Boolean {
        if (lines.size < 2) return false
        if (lines.any { !it.words.isNullOrEmpty() }) return false
        val first = lines.first().time
        return lines.all { it.time == first }
    }

    private val LRC_TIME_TAG_REGEX = "\\[\\d{1,2}:\\d{2}(?:[.:]\\d{1,3})?\\]".toRegex()
    private val LRC_META_LINE_REGEX = "^\\[[a-zA-Z#]+:.*\\]$".toRegex()

    /**
     * Plain lyrics with no timing at all, one entry per non-blank line, all at time 0. Used for
     * display only, where [parseLyrics] would drop every line for lacking a timestamp.
     */
    fun parsePlainLyrics(lyrics: String): List<LyricsEntry> =
        decodeHtmlEntities(lyrics.trim().replace("\\n", "\n").replace("\\r", "\r"))
            .lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !LRC_META_LINE_REGEX.matches(it) }
            .map { it.replace(LRC_TIME_TAG_REGEX, "").replace(RICH_SYNC_TAG_REGEX, "").trim() }
            .filter { it.isNotEmpty() }
            .map { LyricsEntry(0L, it) }

    /** How finely a lyrics payload is timed. Ordered worst to best; compared by ordinal. */
    enum class SyncKind { NONE, PLAIN, LINE, WORD }

    fun syncKind(rawLyrics: String): SyncKind {
        if (rawLyrics.isBlank() || rawLyrics == "LYRICS_NOT_FOUND") return SyncKind.NONE
        val entries = try {
            parseLyrics(rawLyrics)
        } catch (_: Exception) {
            return SyncKind.NONE
        }
        if (entries.isEmpty()) {
            // Parsed to nothing but has text in it — unsynced plain lyrics.
            return if (rawLyrics.any(Char::isLetter)) SyncKind.PLAIN else SyncKind.NONE
        }
        // Every line on the same stamp (usually [00:00.00]) is plain text wearing LRC syntax.
        // Grading it as line-synced let it beat genuinely timed lyrics.
        if (isUnsynced(entries)) return SyncKind.PLAIN
        // One word timing on one line is noise; a genuinely word-synced payload has them
        // throughout. Requiring half the lines keeps a stray <00:12.34> from promoting a
        // line-synced file.
        // counted on the pieces as sent: a one-word line sung in two syllables is still word-timed
        val wordSynced = entries.count { ((it.syllables ?: it.words)?.size ?: 0) > 1 }
        if (wordSynced * 2 >= entries.size && wordSynced > 0) return SyncKind.WORD
        return SyncKind.LINE
    }

    /**
     * Writing systems we care about telling apart when deciding whether a provider handed back
     * the song or handed back a translation of it.
     */
    enum class Script { LATIN, HAN, KANA, HANGUL, CYRILLIC, ARABIC, DEVANAGARI, THAI, GREEK, HEBREW, UNKNOWN }

    private fun scriptOf(ch: Char): Script? {
        if (!ch.isLetter()) return null
        return when (ch.code) {
            in 0x0041..0x024F -> Script.LATIN
            in 0x0370..0x03FF -> Script.GREEK
            in 0x0400..0x052F -> Script.CYRILLIC
            in 0x0590..0x05FF -> Script.HEBREW
            in 0x0600..0x06FF, in 0x0750..0x077F -> Script.ARABIC
            in 0x0900..0x097F -> Script.DEVANAGARI
            in 0x0E00..0x0E7F -> Script.THAI
            in 0x3040..0x30FF -> Script.KANA
            in 0xAC00..0xD7AF, in 0x1100..0x11FF -> Script.HANGUL
            in 0x3400..0x4DBF, in 0x4E00..0x9FFF, in 0xF900..0xFAFF -> Script.HAN
            else -> null
        }
    }

    /**
     * The script most of [text] is written in.
     *
     * Kana wins over Han whenever any kana is present: Japanese is mostly kanji by character count
     * but the presence of kana is decisive, and calling a Japanese song "Chinese" sends it to the
     * pinyin romanizer, which is exactly the "why is this in Chinese" symptom.
     */
    fun dominantScript(text: String): Script {
        val counts = HashMap<Script, Int>()
        var total = 0
        for (ch in text) {
            val s = scriptOf(ch) ?: continue
            counts[s] = (counts[s] ?: 0) + 1
            total++
        }
        if (total == 0) return Script.UNKNOWN
        if ((counts[Script.KANA] ?: 0) > 0) return Script.KANA
        if ((counts[Script.HANGUL] ?: 0) * 4 >= total) return Script.HANGUL
        return counts.maxByOrNull { it.value }?.key ?: Script.UNKNOWN
    }

    // the script the readings are for: kana settles it; otherwise the commonest script that isn't latin, as long as a tenth of the letters are in it, so a korean song with english verses still reads as korean instead of losing its readings
    fun romanizableScript(text: String): Script {
        val counts = HashMap<Script, Int>()
        var total = 0
        for (ch in text) {
            val s = scriptOf(ch) ?: continue
            counts[s] = (counts[s] ?: 0) + 1
            total++
        }
        if (total == 0) return Script.UNKNOWN
        if ((counts[Script.KANA] ?: 0) > 0) return Script.KANA
        val (script, count) = counts.filterKeys { it != Script.LATIN }.maxByOrNull { it.value } ?: return Script.UNKNOWN
        return if (count * 10 >= total) script else Script.UNKNOWN
    }

    // the line read out: each run with a reading replaced by it, the rest (latin words, say) kept as it is
    fun readingLine(text: String, ruby: List<RubyToken>): String = buildString {
        var at = 0
        ruby.sortedBy { it.start }.forEach { token ->
            if (token.start > at) append(text, at, token.start.coerceAtMost(text.length))
            if (isNotEmpty() && !last().isWhitespace()) append(' ')
            append(token.text)
            at = maxOf(at, token.end)
        }
        if (at < text.length) append(text, at, text.length)
    }.trim()

    // the line's timed pieces said in romanisation, so the romanised line can be sung piece by piece like the original; a reading that spans several pieces goes to the first and the rest lengthen it
    suspend fun romanizedWords(
        text: String,
        pieces: List<WordTimestamp>,
        ruby: List<RubyToken>?,
        romanizeWord: suspend (String) -> String?,
    ): List<WordTimestamp>? {
        if (pieces.isEmpty()) return null
        val ranges = wordCharRanges(text, pieces)
        val said = ArrayList<String>(pieces.size)
        if (ruby != null) {
            val tokens = ruby.sortedBy { it.start }
            var next = 0
            for (range in ranges) {
                val out = StringBuilder()
                if (!range.isEmpty()) {
                    var at = range.first
                    while (next < tokens.size && tokens[next].start <= range.last) {
                        val token = tokens[next]
                        next++
                        if (token.start < range.first) continue
                        if (token.start > at) out.append(text, at, token.start)
                        if (out.isNotEmpty() && !out.last().isWhitespace()) out.append(' ')
                        out.append(token.text)
                        at = maxOf(at, token.end)
                    }
                    if (at <= range.last) out.append(text, at, (range.last + 1).coerceAtMost(text.length))
                }
                said += out.toString().trim()
            }
        } else {
            for (piece in pieces) {
                val word = piece.text.trim()
                said += (romanizeWord(word) ?: word).trim()
            }
        }
        // a piece left with nothing to say lengthens the one before it, or waits for the first that says something
        val out = ArrayList<WordTimestamp>(pieces.size)
        var pendingStart: Double? = null
        for (i in pieces.indices) {
            val piece = pieces[i]
            val word = said[i]
            if (word.isEmpty()) {
                if (out.isNotEmpty()) out[out.lastIndex] = out.last().copy(endTime = maxOf(out.last().endTime, piece.endTime))
                else if (pendingStart == null) pendingStart = piece.startTime
                continue
            }
            out += WordTimestamp(word, pendingStart ?: piece.startTime, piece.endTime)
            pendingStart = null
        }
        if (out.isEmpty()) return null
        // a space after every piece but the last, so the pieces add up to the line they make
        return out.mapIndexed { i, piece -> if (i < out.lastIndex) piece.copy(text = piece.text + " ") else piece }
    }

    /** Whether a payload carries `{agent:…}` voice tags — i.e. can drive left/right duet layout. */
    fun hasVoiceTags(rawLyrics: String): Boolean = rawLyrics.contains("{agent:")

    /**
     * Whether a payload would actually lay out on both sides: two or more voices among its lead
     * lines, counting untagged lines as the lead voice. Same rule as the lyrics screen. A provider
     * that tags every line {agent:v1} has voice tags but nothing to put on the right.
     */
    fun hasDistinctVoices(rawLyrics: String): Boolean {
        if (!hasVoiceTags(rawLyrics)) return false
        val lines = try {
            parseLyrics(rawLyrics)
        } catch (_: Exception) {
            return false
        }
        return lines.filter { !it.isBackground }.map { it.agent ?: "v1" }.distinct().size > 1
    }

    /**
     * Character range each timed word occupies inside [text].
     *
     * Word timings arrive as bare strings with no offsets, so the position has to be recovered by
     * walking the line. Mirrors the same walk [com.sandip.nikamusic.ui.player.LyricsGlowLine] does
     * to build its karaoke mask, so the romanisation lines up with the sweep rather than drifting
     * out of step with it. A word that cannot be located yields an empty range and is skipped.
     */
    fun wordCharRanges(text: String, words: List<WordTimestamp>): List<IntRange> {
        var searchFrom = 0
        return words.map { word ->
            val trimmed = word.text.trim()
            if (trimmed.isEmpty()) return@map IntRange.EMPTY
            val start = text.indexOf(trimmed, searchFrom)
            if (start < 0) return@map IntRange.EMPTY
            searchFrom = start + trimmed.length
            start until searchFrom
        }
    }

    /**
     * Romanises Japanese [text] **once, with full sentence context**, returning each token's
     * reading tagged with the character range it came from.
     *
     * The context matters: kuromoji picks a kanji's reading from its neighbours, so feeding it one
     * word at a time gets measurably worse readings than feeding it the line. But rendering wants
     * per-word readings, so the answer is not "romanise per word" — it is "romanise the line and
     * keep the offsets", which is what this returns. Callers regroup the tokens onto whatever word
     * boundaries they care about via [wordCharRanges].
     */
    suspend fun romanizeJapaneseAligned(text: String): List<Pair<IntRange, String>> =
        withContext(Dispatchers.Default) {
            val tokens = kuromojiTokenizer.tokenize(text)
            tokens.mapIndexed { index, token ->
                val reading = token.reading?.takeIf { it.isNotEmpty() && it != "*" } ?: token.surface
                val next = tokens.getOrNull(index + 1)
                val nextReading = next?.reading?.takeIf { it.isNotEmpty() && it != "*" } ?: next?.surface
                val start = token.position
                (start until start + token.surface.length) to katakanaToRomaji(reading, nextReading)
            }
        }

    /**
     * Per-word readings for [text], positioned over the characters they belong to.
     *
     * Returns kuromoji's own tokens rather than regrouping them onto the provider's syllable
     * timings. An earlier version did regroup, and it was wrong twice over: Apple's Japanese
     * timings are per *syllable* (13-22 per line), and a single kuromoji token spans several of
     * them — so every syllable in a token got that token's whole reading and the output repeated
     * itself. Kuromoji's tokens already are the word boundaries a reader wants a reading over.
     *
     * Returns null when there is nothing useful to show, so callers can skip the ruby row.
     */
    suspend fun rubyFor(text: String, script: Script): List<RubyToken>? = when (script) {
        Script.KANA -> romanizeJapaneseAligned(text)
            .mapNotNull { (range, reading) ->
                val clean = reading.trim()
                // Latin runs inside Japanese lyrics ("pool", "JANE DOE") are already readable;
                // a reading over them is noise.
                if (clean.isEmpty() || range.isEmpty()) return@mapNotNull null
                val surface = text.substring(range.first, (range.last + 1).coerceAtMost(text.length))
                if (surface.none { scriptOf(it) == Script.KANA || scriptOf(it) == Script.HAN }) {
                    return@mapNotNull null
                }
                RubyToken(range.first, range.last + 1, clean)
            }
            .takeIf { it.isNotEmpty() }

        Script.HAN -> withContext(Dispatchers.Default) {
            // Pinyin is per character, so each Han character is its own ruby.
            text.mapIndexedNotNull { index, ch ->
                if (ch !in '一'..'鿿') return@mapIndexedNotNull null
                RubyToken(index, index + 1, Pinyin.toPinyin(ch).lowercase(Locale.getDefault()))
            }.takeIf { it.isNotEmpty() }
        }

        else -> null
    }

    /**
     * Which language Latin-script lyrics are in, told by how often each language's commonest small
     * words turn up ("the", "yang", "que"...): script alone can't tell an Indonesian song from its
     * English translation. An ISO-style code ("en", "id"; "ja-Latn" for romanised Japanese), or
     * null for another script, too few words, or no clear winner.
     */
    fun latinLanguage(rawLyrics: String): String? {
        if (lyricsScript(rawLyrics) != Script.LATIN) return null
        val tokens = rawLyrics
            .replace(MarkupRegex, " ")
            .lowercase(Locale.ROOT)
            .split(NonWordRegex)
            .map { it.trim('\'', '’') }
            .filter { it.isNotEmpty() }
        if (tokens.size < 12) return null
        val ranked = LanguageMarkers
            .map { (language, markers) -> language to tokens.count { it in markers } }
            .sortedByDescending { it.second }
        val (best, hits) = ranked.first()
        val runnerUp = ranked.getOrNull(1)?.second ?: 0
        // a tenth of all words, and half again as many as the next language
        return best.takeIf { hits * 10 >= tokens.size && hits * 2 >= runnerUp * 3 }
    }

    /**
     * Timestamps, word timings, voice tags: everything in a payload that isn't the words. Every
     * closing bracket and brace is escaped: Android's regex engine (ICU) rejects a bare "}" that
     * desktop Java accepts, and this is compiled when LyricsUtils first loads - a bare one made
     * every lyrics screen, the player's included, crash on opening.
     */
    private val MarkupRegex = Regex("""\[[^\]]*\]|<[^>]*>|\{[^}]*\}""")
    private val NonWordRegex = Regex("""[^\p{L}'’]+""")

    /**
     * Small words that mark a language, chosen to be told apart: words common to several
     * languages ("a", "de", "la", "no") are left out, since they would count for all of them.
     */
    private val LanguageMarkers: Map<String, Set<String>> = mapOf(
        "en" to setOf(
            "the", "and", "you", "i", "i'm", "my", "it's", "don't", "your", "that", "what", "with",
            "this", "be", "just", "can't", "won't", "when", "all", "for", "of", "we", "but", "now",
            "never", "you're", "i'll", "was", "are", "can", "know", "like", "want", "she", "he",
        ),
        "id" to setOf(
            "yang", "dan", "aku", "kau", "kamu", "ini", "itu", "tak", "tidak", "dengan", "untuk",
            "akan", "ada", "dalam", "hati", "saja", "bisa", "tapi", "jangan", "sudah", "lagi",
            "karena", "selalu", "engkau", "dia", "kita", "cinta", "ku", "mu", "dari", "pun",
            "pernah", "hanya", "semua", "takkan", "denganmu", "padamu", "diriku", "dirimu",
        ),
        "es" to setOf(
            "que", "y", "el", "los", "las", "yo", "pero", "porque", "quiero", "eres", "estoy",
            "cuando", "para", "del", "como", "más", "qué", "nada", "todo", "tú", "mí", "sí", "esta",
            "está", "contigo", "corazón", "vida", "siempre", "nunca", "puedo",
        ),
        "pt" to setOf(
            "você", "não", "eu", "meu", "minha", "é", "um", "pra", "tudo", "nao", "voce", "também",
            "mais", "quando", "sem", "isso", "ela", "ele", "só", "vou", "seu", "sua", "nós", "estou",
            "coração", "agora", "sempre", "nunca",
        ),
        "fr" to setOf(
            "je", "les", "et", "est", "pas", "pour", "dans", "moi", "toi", "mon", "c'est", "j'ai",
            "qui", "sur", "une", "des", "du", "au", "ne", "plus", "tout", "elle", "nous", "vous",
            "suis", "ça", "avec", "mais",
        ),
        "de" to setOf(
            "der", "die", "das", "und", "ich", "nicht", "ist", "ein", "eine", "mich", "mir", "dich",
            "dir", "wir", "mein", "auf", "mit", "wie", "nur", "auch", "sich", "noch", "bin", "bist",
            "kein", "immer", "zu",
        ),
        "it" to setOf(
            "il", "che", "non", "sono", "sei", "io", "per", "mio", "mia", "più", "cosa", "ancora",
            "questo", "della", "nel", "perché", "tutto", "anche", "gli", "voglio", "amore",
        ),
        "tl" to setOf(
            "ang", "ng", "sa", "ko", "mo", "na", "ka", "ako", "ikaw", "hindi", "lang", "mga",
            "kita", "ay", "naman", "pa", "sana", "akin", "ito", "iyong", "natin", "tayo", "puso",
        ),
        "nl" to setOf(
            "het", "een", "ik", "niet", "van", "dat", "mijn", "jij", "wij", "voor", "maar", "zijn",
            "wat", "wel", "nog", "ook", "geen", "heb", "ben",
        ),
        "tr" to setOf(
            "bir", "ve", "ben", "sen", "bu", "için", "çok", "gibi", "beni", "seni", "var", "yok",
            "değil", "olan", "her", "ama", "daha", "şey", "kadar",
        ),
        "vi" to setOf(
            "anh", "em", "và", "không", "là", "của", "một", "người", "yêu", "có", "những", "cho",
            "đã", "mình", "trong", "như", "tôi", "thì", "này",
        ),
        "ja-Latn" to setOf(
            "wa", "ga", "wo", "ni", "mo", "kimi", "boku", "watashi", "anata", "dake", "kara",
            "made", "kokoro", "demo", "itsumo", "nai", "koto", "toki", "naka", "sora",
        ),
        "ko-Latn" to setOf(
            "naega", "neol", "neoreul", "nan", "nae", "neon", "geu", "nal", "naneun", "neoui",
            "uri", "saranghae", "jigeum", "modeun", "ije", "geurae", "eonjena",
        ),
        "hi-Latn" to setOf(
            "hai", "hain", "mein", "main", "tera", "teri", "tere", "mera", "meri", "mere",
            "dil", "pyaar", "pyar", "ishq", "nahi", "nahin", "nhi", "bhi", "toh", "kya",
            "koi", "hum", "tum", "tujhe", "tujhko", "mujhe", "mujhko", "aur", "tha", "thi",
            "yeh", "woh", "kaise", "kyun", "kabhi", "apna", "apni", "apne", "saath", "zindagi",
        ),
    )

    /** The script of the lyric text only, with timestamps and markup stripped. */
    fun lyricsScript(rawLyrics: String): Script {
        val stripped = rawLyrics
            .replace(Regex("\\[[^\\]]*\\]"), " ")
            .replace(Regex("<[^>]*>"), " ")
        return dominantScript(stripped)
    }

    suspend fun romanizeJapanese(text: String): String = withContext(Dispatchers.Default) {
        val tokens = kuromojiTokenizer.tokenize(text)
        val romanizedTokens = tokens.mapIndexed { index, token ->
            val currentReading = if (token.reading.isNullOrEmpty() || token.reading == "*") {
                token.surface
            } else {
                token.reading
            }
            val nextTokenReading = if (index + 1 < tokens.size) {
                tokens[index + 1].reading?.takeIf { it.isNotEmpty() && it != "*" } ?: tokens[index + 1].surface
            } else {
                null
            }
            katakanaToRomaji(currentReading, nextTokenReading)
        }
        romanizedTokens.joinToString(" ")
    }

    // a word's katakana reading in romaji; the next word's reading is only for a small tsu that ends this one
    fun katakanaToRomaji(katakana: String?, nextKatakana: String? = null): String {
        if (katakana.isNullOrEmpty()) return ""

        val romaji = StringBuilder(katakana.length * 2)
        var i = 0
        while (i < katakana.length) {
            val ch = katakana[i]
            when (ch) {
                // a small tsu doubles the sound right after it, so ハッピー is happii, not the next word's letter
                'ッ' -> {
                    val after = if (i + 1 < katakana.length) katakana.substring(i + 1) else nextKatakana
                    doubledConsonant(after)?.let { romaji.append(it) }
                    i++
                }
                // a long-vowel mark stretches the vowel before it, so デザート reads dezaato instead of dezato
                'ー' -> {
                    romaji.lastOrNull()?.takeIf { it in "aiueo" }?.let { romaji.append(it) }
                    i++
                }
                else -> {
                    val pair = if (i + 1 < katakana.length) KANA_ROMAJI_MAP[katakana.substring(i, i + 2)] else null
                    if (pair != null) {
                        romaji.append(pair)
                        i += 2
                    } else {
                        romaji.append(KANA_ROMAJI_MAP[ch.toString()] ?: ch.toString())
                        i++
                    }
                }
            }
        }
        return romaji.toString().lowercase()
    }

    // the consonant a small tsu doubles before kana, or null when there's no consonant to double
    private fun doubledConsonant(kana: String?): Char? {
        if (kana.isNullOrEmpty()) return null
        val sound = (if (kana.length >= 2) KANA_ROMAJI_MAP[kana.substring(0, 2)] else null)
            ?: KANA_ROMAJI_MAP[kana.substring(0, 1)]
            ?: return null
        return when {
            sound.startsWith("ch") -> 't'
            sound.first() in "aiueon" -> null
            else -> sound.first()
        }
    }

    suspend fun romanizeKorean(text: String): String = withContext(Dispatchers.Default) {
        val romajaBuilder = StringBuilder()
        var prevFinal: String? = null

        for (i in text.indices) {
            val char = text[i]
            if (char in '\uAC00'..'\uD7A3') {
                val syllableIndex = char.code - 0xAC00
                val choIndex = syllableIndex / (21 * 28)
                val jungIndex = (syllableIndex % (21 * 28)) / 28
                val jongIndex = syllableIndex % 28

                val choChar = (0x1100 + choIndex).toChar().toString()
                val jungChar = (0x1161 + jungIndex).toChar().toString()
                val jongChar = if (jongIndex == 0) null else (0x11A7 + jongIndex).toChar().toString()

                if (prevFinal != null) {
                    val contextKey = prevFinal + choChar
                    val jong = HANGUL_ROMAJA_MAP["jong"]?.get(contextKey)
                        ?: HANGUL_ROMAJA_MAP["jong"]?.get(prevFinal)
                        ?: prevFinal
                    romajaBuilder.append(jong)
                }

                val cho = HANGUL_ROMAJA_MAP["cho"]?.get(choChar) ?: choChar
                val jung = HANGUL_ROMAJA_MAP["jung"]?.get(jungChar) ?: jungChar
                romajaBuilder.append(cho).append(jung)
                prevFinal = jongChar
            } else {
                if (prevFinal != null) {
                    val jong = HANGUL_ROMAJA_MAP["jong"]?.get(prevFinal) ?: prevFinal
                    romajaBuilder.append(jong)
                    prevFinal = null
                }
                romajaBuilder.append(char)
            }
        }

        if (prevFinal != null) {
            val jong = HANGUL_ROMAJA_MAP["jong"]?.get(prevFinal) ?: prevFinal
            romajaBuilder.append(jong)
        }

        romajaBuilder.toString()
    }

    suspend fun romanizeChinese(text: String): String = withContext(Dispatchers.Default) {
        if (text.isEmpty()) return@withContext ""
        val builder = StringBuilder(text.length * 2)
        for (ch in text) {
            if (ch in '\u4E00'..'\u9FFF') {
                val py = Pinyin.toPinyin(ch).lowercase(Locale.getDefault())
                builder.append(py).append(' ')
            } else {
                builder.append(ch)
            }
        }

        builder.toString()
            .replace(Regex("\\s+([,.!?;:])"), "$1")
            .replace(Regex("\\s+([，。！？；：、（）《》〈〉【】『』「」])"), "$1")
            .trim()
    }

    suspend fun romanizeCyrillic(text: String): String? = withContext(Dispatchers.Default) {
        if (text.isEmpty()) return@withContext null

        val cyrillicChars = text.filter { it in '\u0400'..'\u04FF' }

        if (cyrillicChars.isEmpty() ||
            (cyrillicChars.length == 1 && (cyrillicChars[0] == 'е' || cyrillicChars[0] == 'Е'))) {
            return@withContext null
        }

        when {
            isRussian(text) -> romanizeRussianInternal(text)
            isUkrainian(text) -> romanizeUkrainianInternal(text)
            isSerbian(text) -> romanizeSerbianInternal(text)
            isBulgarian(text) -> romanizeBulgarianInternal(text)
            isBelarusian(text) -> romanizeBelarusianInternal(text)
            isKyrgyz(text) -> romanizeKyrgyzInternal(text)
            isMacedonian(text) -> romanizeMacedonianInternal(text)
            else -> null
        }
    }

    private fun romanizeRussianInternal(text: String): String {
        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEachIndexed { _, word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                romajiBuilder.append(word)
            } else {
                var charIndex = 0
                while (charIndex < word.length) {
                    var consumed = false

                    if (charIndex + 2 < word.length) {
                        val threeCharCandidate = word.substring(charIndex, charIndex + 3)
                        if (RUSSIAN_ROMAJI_MAP.containsKey(threeCharCandidate)) {
                            romajiBuilder.append(RUSSIAN_ROMAJI_MAP[threeCharCandidate])
                            charIndex += 3
                            consumed = true
                        }
                    }

                    if (!consumed) {
                        val charStr = word[charIndex].toString()

                        if ((charStr == "е" || charStr == "Е") && (charIndex == 0 || word[charIndex - 1].isWhitespace())) {
                            romajiBuilder.append(if (charStr == "е") "ye" else "Ye")
                        } else {

                            val romanizedChar = GENERAL_CYRILLIC_ROMAJI_MAP[charStr] ?: charStr
                            romajiBuilder.append(romanizedChar)
                        }
                        charIndex += 1
                    }
                }
            }
        }
        return romajiBuilder.toString()
    }

    private fun romanizeUkrainianInternal(text: String): String {
        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEachIndexed { _, word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                romajiBuilder.append(word)
            } else {
                var charIndex = 0
                while (charIndex < word.length) {
                    val charStr = word[charIndex].toString()
                    var processed = false

                    if (charIndex > 0 && word[charIndex - 1].isLetter() && !isCyrillicVowel(word[charIndex - 1])) {

                        if (charStr == "Ю") {
                            romajiBuilder.append("Iu")
                            processed = true
                        } else if (charStr == "ю") {
                            romajiBuilder.append("iu")
                            processed = true
                        } else if (charStr == "Я") {
                            romajiBuilder.append("Ia")
                            processed = true
                        } else if (charStr == "я") {
                            romajiBuilder.append("ia")
                            processed = true
                        }
                    }

                    if (!processed) {
                        romajiBuilder.append(UKRAINIAN_ROMAJI_MAP[charStr] ?: GENERAL_CYRILLIC_ROMAJI_MAP[charStr] ?: charStr)
                    }
                    charIndex++
                }
            }
        }
        return romajiBuilder.toString()
    }

    private fun romanizeSerbianInternal(text: String): String {
        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEachIndexed { _, word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                romajiBuilder.append(word)
            } else {
                var charIndex = 0
                while (charIndex < word.length) {
                    val charStr = word[charIndex].toString()
                    val romanizedChar = SERBIAN_ROMAJI_MAP[charStr] ?: GENERAL_CYRILLIC_ROMAJI_MAP[charStr] ?: charStr
                    romajiBuilder.append(romanizedChar)
                    charIndex++
                }
            }
        }
        return romajiBuilder.toString()
    }

    private fun romanizeBulgarianInternal(text: String): String {
        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEachIndexed { _, word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                romajiBuilder.append(word)
            } else {
                var charIndex = 0
                while (charIndex < word.length) {
                    val charStr = word[charIndex].toString()
                    val romanizedChar = BULGARIAN_ROMAJI_MAP[charStr] ?: GENERAL_CYRILLIC_ROMAJI_MAP[charStr] ?: charStr
                    romajiBuilder.append(romanizedChar)
                    charIndex++
                }
            }
        }
        return romajiBuilder.toString()
    }

    private fun romanizeBelarusianInternal(text: String): String {
        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEach { word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                romajiBuilder.append(word)
            } else {
                var charIndex = 0
                while (charIndex < word.length) {
                    val charStr = word[charIndex].toString()

                    if ((charStr == "е" || charStr == "Е") && (charIndex == 0 || word[charIndex - 1].isWhitespace())) {
                        romajiBuilder.append(if (charStr == "е") "ye" else "Ye")
                    } else {

                        val romanizedChar = BELARUSIAN_ROMAJI_MAP[charStr] ?: GENERAL_CYRILLIC_ROMAJI_MAP[charStr] ?: charStr
                        romajiBuilder.append(romanizedChar)
                    }
                    charIndex += 1
                }
            }
        }

        return romajiBuilder.toString()
    }

    private fun romanizeKyrgyzInternal(text: String): String {
        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEachIndexed { _, word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                romajiBuilder.append(word)
            } else {
                var charIndex = 0
                while (charIndex < word.length) {
                    val charStr = word[charIndex].toString()
                    val romanizedChar = KYRGYZ_ROMAJI_MAP[charStr] ?: GENERAL_CYRILLIC_ROMAJI_MAP[charStr] ?: charStr
                    romajiBuilder.append(romanizedChar)
                    charIndex++
                }
            }
        }
        return romajiBuilder.toString()
    }

    private fun romanizeMacedonianInternal(text: String): String {
        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEachIndexed { _, word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                romajiBuilder.append(word)
            } else {
                var charIndex = 0
                while (charIndex < word.length) {
                    val charStr = word[charIndex].toString()
                    val romanizedChar = MACEDONIAN_ROMAJI_MAP[charStr] ?: GENERAL_CYRILLIC_ROMAJI_MAP[charStr] ?: charStr
                    romajiBuilder.append(romanizedChar)
                    charIndex++
                }
            }
        }
        return romajiBuilder.toString()
    }

    fun isRussian(text: String): Boolean {
        return text.any { char ->
            RUSSIAN_CYRILLIC_LETTERS.contains(char.toString())
        } && text.all { char ->
            val charStr = char.toString()
            RUSSIAN_CYRILLIC_LETTERS.contains(charStr) || !charStr.matches("[\\u0400-\\u04FF]".toRegex())
        }
    }

    fun isUkrainian(text: String): Boolean {
        return text.any { char ->
            UKRAINIAN_CYRILLIC_LETTERS.contains(char.toString()) || UKRAINIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString())
        } && text.all { char ->
            UKRAINIAN_CYRILLIC_LETTERS.contains(char.toString()) || UKRAINIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString()) || !char.toString().matches("[\\u0400-\\u04FF]".toRegex())
        }
    }

    fun isSerbian(text: String): Boolean {
        return text.any { char ->
            SERBIAN_CYRILLIC_LETTERS.contains(char.toString()) || SERBIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString())
        } && text.all { char ->
            SERBIAN_CYRILLIC_LETTERS.contains(char.toString()) || SERBIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString()) || !char.toString().matches("[\\u0400-\\u04FF]".toRegex())
        }
    }

    fun isBulgarian(text: String): Boolean {
        return text.any { char ->
            BULGARIAN_CYRILLIC_LETTERS.contains(char.toString())
        } && text.all { char ->
            BULGARIAN_CYRILLIC_LETTERS.contains(char.toString()) || !char.toString().matches("[\\u0400-\\u04FF]".toRegex())
        }
    }

    fun isBelarusian(text: String): Boolean {
        return text.any { char ->
            BELARUSIAN_CYRILLIC_LETTERS.contains(char.toString()) || BELARUSIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString())
        } && text.all { char ->
            BELARUSIAN_CYRILLIC_LETTERS.contains(char.toString()) || BELARUSIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString()) || !char.toString().matches("[\\u0400-\\u04FF]".toRegex())
        }
    }

    fun isKyrgyz(text: String): Boolean {
        return text.any { char ->
            KYRGYZ_CYRILLIC_LETTERS.contains(char.toString()) || KYRGYZ_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString())
        } && text.all { char ->
            KYRGYZ_CYRILLIC_LETTERS.contains(char.toString()) || KYRGYZ_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString()) || !char.toString().matches("[\\u0400-\\u04FF]".toRegex())
        }
    }

    fun isMacedonian(text: String): Boolean {
        return text.any { char ->
            MACEDONIAN_CYRILLIC_LETTERS.contains(char.toString()) || MACEDONIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString())
        } && text.all { char ->
            MACEDONIAN_CYRILLIC_LETTERS.contains(char.toString()) || MACEDONIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString()) || !char.toString().matches("[\\u0400-\\u04FF]".toRegex())
        }
    }

    fun isJapanese(text: String): Boolean {
        return text.any { char ->
            (char in '\u3040'..'\u309F') ||
                    (char in '\u30A0'..'\u30FF') ||
                    (char in '\u4E00'..'\u9FFF')
        }
    }

    fun isKorean(text: String): Boolean {
        return text.any { char ->
            (char in '\uAC00'..'\uD7A3')
        }
    }

    fun isChinese(text: String): Boolean {
        if (text.isEmpty()) return false
        val cjkCharCount = text.count { char -> char in '\u4E00'..'\u9FFF' }
        val hiraganaKatakanaCount = text.count { char -> (char in '\u3040'..'\u309F') || (char in '\u30A0'..'\u30FF') }
        return cjkCharCount > 0 && (hiraganaKatakanaCount.toDouble() / text.length.toDouble()) < 0.1
    }

    fun isHindi(text: String): Boolean {
        return text.any { char ->
            char in '\u0900'..'\u097F'
        }
    }

    suspend fun romanizeHindi(text: String): String = withContext(Dispatchers.Default) {
        val sb = StringBuilder(text.length)
        var i = 0
        while (i < text.length) {
            var consumed = false

            if (i + 1 < text.length) {
                val twoCharCandidate = text.substring(i, i + 2)
                val mappedTwoChar = DEVANAGARI_ROMAJI_MAP[twoCharCandidate]
                if (mappedTwoChar != null) {
                    sb.append(mappedTwoChar)
                    i += 2
                    consumed = true
                }
            }

            if (!consumed) {
                val charStr = text[i].toString()
                sb.append(DEVANAGARI_ROMAJI_MAP[charStr] ?: charStr)
                i += 1
            }
        }
        sb.toString()
    }

    fun isPunjabi(text: String): Boolean {
        return text.any { char ->
            char in '\u0A00'..'\u0A7F'
        }
    }

    suspend fun romanizePunjabi(text: String): String = withContext(Dispatchers.Default) {
        val sb = StringBuilder(text.length)
        var i = 0
        while (i < text.length) {
            val char = text[i]
            var consumed = false

            if (char == '\u0A71') {

                 if (i + 1 < text.length) {
                     val nextCharStr = text[i+1].toString()
                     val nextMapped = GURMUKHI_ROMAJI_MAP[nextCharStr]
                     if (nextMapped != null && nextMapped.isNotEmpty()) {
                         sb.append(nextMapped[0])
                     }
                 }
                 i++
                 continue
            }

            if (i + 1 < text.length) {
                val twoCharCandidate = text.substring(i, i + 2)
                val mappedTwoChar = GURMUKHI_ROMAJI_MAP[twoCharCandidate]
                if (mappedTwoChar != null) {
                    sb.append(mappedTwoChar)
                    i += 2
                    consumed = true
                }
            }

            if (!consumed) {
                val str = char.toString()
                sb.append(GURMUKHI_ROMAJI_MAP[str] ?: str)
                i++
            }
        }
        sb.toString()
    }

    private fun isCyrillicVowel(char: Char): Boolean {
        return "АаЕеЄєИиІіЇїОоУуЮюЯяЫыЭэ".contains(char)
    }
}

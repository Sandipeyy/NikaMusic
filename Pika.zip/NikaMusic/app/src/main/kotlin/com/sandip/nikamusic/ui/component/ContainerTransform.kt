// ContainerTransform.kt

package com.sandip.nikamusic.ui.component

import android.os.Build
import android.view.RoundedCorner
import android.view.View
import androidx.annotation.RequiresApi
import androidx.compose.animation.BoundsTransform
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.VisibilityThreshold
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.RememberObserver
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onPlaced
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import androidx.navigation.NavBackStackEntry

/** every Home cover card is drawn with this radius, so the open transition starts from it */
var HomeCardCornerRadius by mutableStateOf(25.dp)

/** the soft spring a screen grows out of its card on (~0.6s), interruptible like iOS opening an app */
const val ContainerOpenDamping = 0.88f
const val ContainerOpenStiffness = 150f

/**
 * the way back is a fixed-length ease instead of a spring. going back has to compose Home from
 * scratch, so its first frame is slow, and a spring does ~40% of its travel in the first 100ms:
 * that part got skipped and the shrink visibly jumped. this curve starts gently (~12% at 100ms),
 * so a slow first frame costs nothing you can see, and a back swipe (which scrubs the transition
 * by time) tracks the finger instead of racing ahead of it. Home comes forward on the same clock.
 */
const val ContainerCloseMillis = 560
val ContainerCloseEasing = CubicBezierEasing(0.4f, 0f, 0.1f, 1f)

// both sides of a match animate their own bounds, so they must pick the same spec: shrinking
// means closing
@OptIn(ExperimentalSharedTransitionApi::class)
private val ContainerBoundsTransform = BoundsTransform { initial, target ->
    if (target.width < initial.width) {
        tween(ContainerCloseMillis, easing = ContainerCloseEasing)
    } else {
        spring(
            dampingRatio = ContainerOpenDamping,
            stiffness = ContainerOpenStiffness,
            visibilityThreshold = Rect.VisibilityThreshold,
        )
    }
}

/**
 * what each tapped card looked like (width and corner radius, by its screen's key) plus the width an
 * opened screen settles at, so both sides of the transition clip to exactly the same outline.
 * only touched on the main thread.
 */
private object ContainerTransformRegistry {
    val sourceWidths = HashMap<String, Float>()
    val sourceRadii = HashMap<String, Dp>()
    val sourceCovers = HashMap<String, String>()
    // which screens are showing a card for each key right now, so a page can tell where it was opened from
    val hosts = HashMap<String, MutableList<String>>()
    // every card showing each screen key, in the order they appeared
    val scopedOwners = HashMap<String, MutableList<TransformOwner>>()
    // the card a key's morph belongs to once a finger or the remote picked it, read in composition so the morph moves to it
    val claimed = mutableStateMapOf<String, TransformOwner>()
    var targetWidth = 0f
}

// the nav entry this is composed in, "" outside a nav host
@Composable
private fun currentScreenId(): String = (LocalViewModelStoreOwner.current as? NavBackStackEntry)?.id.orEmpty()

// cards only pair with a page inside one screen's key, so Home's and Library's Liked cards never morph into each other on a tab switch
private fun screenKey(key: String, screenId: String?) = "$key@$screenId"

/**
 * the cover the tapped card was showing. the opened screen draws it from its very first frame,
 * instead of growing an empty canvas while its own data is still loading.
 */
fun containerTransformCover(key: String?): String? =
    key?.let { ContainerTransformRegistry.sourceCovers[it] }

/**
 * the corner radius is worked out from the live bounds instead of its own animation clock, so it
 * can never drift from the size spring, and a predictive back drag scrubs both at once.
 */
@OptIn(ExperimentalSharedTransitionApi::class)
private class MorphingCornerClip(
    private val key: String,
    private val startRadius: Dp,
    private val endRadiusPx: () -> Float,
) : SharedTransitionScope.OverlayClip {
    private val path = Path()

    override fun getClipPath(
        state: SharedTransitionScope.SharedContentState,
        bounds: Rect,
        layoutDirection: LayoutDirection,
        density: Density,
    ): Path {
        val from = ContainerTransformRegistry.sourceWidths[key]
        val to = ContainerTransformRegistry.targetWidth
        val t = if (from != null && to > from + 1f) {
            ((bounds.width - from) / (to - from)).coerceIn(0f, 1f)
        } else {
            1f
        }
        val start = ContainerTransformRegistry.sourceRadii[key] ?: startRadius
        val radius = lerp(with(density) { start.toPx() }, endRadiusPx(), t)
        path.rewind()
        path.addRoundRect(RoundRect(bounds, CornerRadius(radius)))
        return path
    }
}

@Composable
private fun rememberMorphingCornerClip(key: String, startRadius: Dp): MorphingCornerClip {
    val view = LocalView.current
    return remember(key, startRadius, view) {
        MorphingCornerClip(key, startRadius) { screenCornerRadiusPx(view) }
    }
}

private fun screenCornerRadiusPx(view: View): Float =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) roundedCornerRadiusPx(view) else 0f

@RequiresApi(Build.VERSION_CODES.S)
private fun roundedCornerRadiusPx(view: View): Float =
    view.rootWindowInsets?.getRoundedCorner(RoundedCorner.POSITION_TOP_LEFT)?.radius?.toFloat() ?: 0f

// home can show liked songs in two or three rows at once; only one card per screen may carry the morph, and it has to be the one tapped or the page opened from the wrong card or from nowhere
private class TransformOwner(private val scoped: String) : RememberObserver {
    private val owners = ContainerTransformRegistry.scopedOwners.getOrPut(scoped) { mutableListOf() }.also { it += this }
    var coordinates: LayoutCoordinates? = null

    // read while composing, so a new claim moves the morph onto this card
    val isPrimary: Boolean
        get() {
            val picked = ContainerTransformRegistry.claimed[scoped]
            return if (picked != null && picked in owners) picked === this else owners.first() === this
        }

    fun claim() {
        if (owners.size > 1 && ContainerTransformRegistry.claimed[scoped] !== this) ContainerTransformRegistry.claimed[scoped] = this
    }

    fun contains(point: Offset): Boolean =
        coordinates?.takeIf { it.isAttached }?.boundsInWindow()?.contains(point) == true

    override fun onRemembered() = Unit
    override fun onForgotten() = release()
    override fun onAbandoned() = release()

    private fun release() {
        val wasPrimary = isPrimary
        owners.remove(this)
        when {
            owners.isEmpty() -> {
                ContainerTransformRegistry.scopedOwners.remove(scoped)
                ContainerTransformRegistry.claimed.remove(scoped)
            }
            // the card left (scrolled away, say), so the one still showing takes over instead of nobody
            wasPrimary -> ContainerTransformRegistry.claimed[scoped] = owners.first()
        }
    }
}

/** a finger went down at [point] (window pixels): of the cards sharing a key, the one under it is the one the page will grow from */
fun claimContainerTransformAt(point: Offset) {
    ContainerTransformRegistry.scopedOwners.values.forEach { owners ->
        if (owners.size > 1) owners.firstOrNull { it.contains(point) }?.claim()
    }
}

/** the tapped side: a cover card on Home (or anywhere a playlist can be opened from) */
@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun Modifier.containerTransformSource(
    key: String?,
    cornerRadius: Dp = HomeCardCornerRadius,
    coverUrl: String? = null,
): Modifier {
    if (key == null) return this
    val sharedScope = LocalSharedTransitionScope.current ?: return this
    val visibilityScope = LocalNavAnimatedContentScope.current ?: return this
    val screenId = currentScreenId()
    val scoped = screenKey(key, screenId)
    val owner = remember(scoped) { TransformOwner(scoped) }
    DisposableEffect(key, screenId) {
        val hosts = ContainerTransformRegistry.hosts.getOrPut(key) { mutableListOf() }
        hosts += screenId
        onDispose {
            hosts.remove(screenId)
            if (hosts.isEmpty()) ContainerTransformRegistry.hosts.remove(key)
        }
    }
    val clip = rememberMorphingCornerClip(scoped, cornerRadius)

    return with(sharedScope) {
        val placed = this@containerTransformSource
            .onPlaced {
                owner.coordinates = it
                ContainerTransformRegistry.sourceWidths[scoped] = it.size.width.toFloat()
                ContainerTransformRegistry.sourceRadii[scoped] = cornerRadius
                if (coverUrl != null) ContainerTransformRegistry.sourceCovers[key] = coverUrl
            }
            // on a tv the remote picks a card by focusing it
            .onFocusChanged { if (it.hasFocus) owner.claim() }
        if (!owner.isPrimary) {
            placed
        } else {
            placed.sharedBounds(
                sharedContentState = rememberSharedContentState(scoped),
                animatedVisibilityScope = visibilityScope,
                // the opened screen is drawn above the card, so the card only has to be gone
                // under it on the way out and back in under it before it fades off
                enter = fadeIn(tween(220, delayMillis = 100)),
                exit = fadeOut(tween(220, delayMillis = 40)),
                boundsTransform = ContainerBoundsTransform,
                resizeMode = SharedTransitionScope.ResizeMode.scaleToBounds(ContentScale.FillWidth, Alignment.TopCenter),
                clipInOverlayDuringTransition = clip,
            )
        }
    }
}

/** the opened side: the root of the screen that grows out of the card */
@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun Modifier.containerTransformTarget(
    key: String?,
    sourceCornerRadius: Dp = HomeCardCornerRadius,
): Modifier {
    if (key == null) return this
    val sharedScope = LocalSharedTransitionScope.current ?: return this
    val visibilityScope = LocalNavAnimatedContentScope.current ?: return this
    // the screen still showing this card as the page comes in is the one it opened from, saved so a tab coming back can't re-pick it
    val own = currentScreenId()
    val scoped = rememberSaveable(key) { screenKey(key, ContainerTransformRegistry.hosts[key]?.lastOrNull { it != own }) }
    val clip = rememberMorphingCornerClip(scoped, sourceCornerRadius)

    return with(sharedScope) {
        this@containerTransformTarget
            .onSizeChanged { ContainerTransformRegistry.targetWidth = it.width.toFloat() }
            .sharedBounds(
                sharedContentState = rememberSharedContentState(scoped),
                animatedVisibilityScope = visibilityScope,
                // on the way back it stays solid for the first stretch of the shrink, so it doesn't
                // ghost over Home while it's still nearly full screen, and is gone by ~320ms when
                // the card is almost home and its own cover takes over
                enter = fadeIn(tween(280)),
                exit = fadeOut(tween(200, delayMillis = 120)),
                boundsTransform = ContainerBoundsTransform,
                resizeMode = SharedTransitionScope.ResizeMode.scaleToBounds(ContentScale.FillWidth, Alignment.TopCenter),
                zIndexInOverlay = 1f,
                clipInOverlayDuringTransition = clip,
            )
    }
}

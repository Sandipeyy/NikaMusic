// MediaItemExt.kt

package com.sandip.nikamusic.extensions

import android.os.Bundle
import androidx.core.net.toUri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata.MEDIA_TYPE_MUSIC
import com.music.innertube.models.SongItem
import com.sandip.nikamusic.db.entities.Song
import com.sandip.nikamusic.models.MediaMetadata
import com.sandip.nikamusic.models.toMediaMetadata
import com.sandip.nikamusic.songedit.SongEdits

val MediaItem.metadata: MediaMetadata?
    get() = localConfiguration?.tag as? MediaMetadata

fun Song.toMediaItem() = MediaItem.Builder()
    .setMediaId(song.id)
    .setUri(if (song.isLocal && song.localUri != null) song.localUri else song.id)
    .setCustomCacheKey(song.id)
    .setTag(toMediaMetadata())
    .setMediaMetadata(
        androidx.media3.common.MediaMetadata.Builder()
            .setTitle(song.title)
            .setSubtitle(artists.joinToString { it.name })
            .setArtist(artists.joinToString { it.name })
            .setArtworkUri(song.thumbnailUrl?.toUri())
            .setAlbumTitle(song.albumName)
            .setAlbumArtist(artists.firstOrNull()?.name)
            .setDisplayTitle(song.title)
            .setMediaType(MEDIA_TYPE_MUSIC)
            .setIsBrowsable(false)
            .setIsPlayable(true)
            .setExtras(Bundle().apply {
                putString("artwork_uri", song.thumbnailUrl)
            })
            .build()
    )
    .build()

// built through the metadata so a youtube result picks up the song's hand edits too
fun SongItem.toMediaItem() = toMediaMetadata().toMediaItem()

// the hand edits from the song edit sheet go on here, so the notification, the lock screen and the queue show them
fun MediaMetadata.toMediaItem(): MediaItem = SongEdits.applyTo(this).buildMediaItem()

private fun MediaMetadata.buildMediaItem() = MediaItem.Builder()
    .setMediaId(id)
    .setUri(localUri ?: id)
    .setCustomCacheKey(id)
    .setTag(this)
    .setMediaMetadata(
        androidx.media3.common.MediaMetadata.Builder()
            .setTitle(title)
            .setSubtitle(artists.joinToString { it.name })
            .setArtist(artists.joinToString { it.name })
            .setArtworkUri(thumbnailUrl?.toUri())
            .setAlbumTitle(album?.title)
            .setAlbumArtist(artists.firstOrNull()?.name)
            .setDisplayTitle(title)
            .setMediaType(MEDIA_TYPE_MUSIC)
            .setIsBrowsable(false)
            .setIsPlayable(true)
            .setExtras(Bundle().apply {
                thumbnailUrl?.let { putString("artwork_uri", it) }
            })
            .build()
    )
    .build()

/**
 * Flags a song the infinite queue lined up on its own (the queue's "Autoplay" section), as
 * opposed to one the user queued. Kept in the media metadata extras so it travels with the item
 * through the player's timeline.
 */
private const val AutoplayExtra = "nika.autoplay"

val MediaItem.isAutoplay: Boolean
    get() = mediaMetadata.extras?.getBoolean(AutoplayExtra, false) == true

fun MediaItem.withAutoplay(autoplay: Boolean): MediaItem {
    if (isAutoplay == autoplay) return this
    val extras = Bundle(mediaMetadata.extras ?: Bundle()).apply { putBoolean(AutoplayExtra, autoplay) }
    return buildUpon()
        .setMediaMetadata(mediaMetadata.buildUpon().setExtras(extras).build())
        .build()
}

/**
 * Flags a song the user queued by hand ("Add to Queue" / "Play next"), as opposed to one that
 * came with the queue they started or one Autoplay lined up. These are the queue's "Next in Queue"
 * songs: they play ahead of everything else, and starting another song doesn't drop them.
 */
private const val ManualQueueExtra = "nika.manualqueue"

val MediaItem.isManualQueued: Boolean
    get() = mediaMetadata.extras?.getBoolean(ManualQueueExtra, false) == true

fun MediaItem.withManualQueued(manual: Boolean): MediaItem {
    if (isManualQueued == manual) return this
    val extras = Bundle(mediaMetadata.extras ?: Bundle()).apply { putBoolean(ManualQueueExtra, manual) }
    return buildUpon()
        .setMediaMetadata(mediaMetadata.buildUpon().setExtras(extras).build())
        .build()
}
